import { useEffect, useMemo, useState } from "react";
import "./App.css";
import { enhancePlanInBrowser } from "./browserAi";

type Theme = { id: string; name: string; description: string };
type Puzzle = {
  id: string;
  category: "logic" | "physical" | "electronic";
  title: string;
  objective: string;
  howItWorks: string;
  themeFitReason?: string;
  referenceLinks: { title: string; url: string }[];
  solveSteps: string[];
  difficulty: "easy" | "medium" | "hard";
  electronicDetails?: {
    parts: string[];
    wiringDiagram: string[];
    wiringDiagramSvg: string;
    buildSteps: string[];
    arduinoCode: string;
  };
};
type StoryPlan = {
  situation: string;
  premise: string;
  missionObjective: string;
  progressionRule: string;
  stages: Array<{
    stage: number;
    title: string;
    storyBeat: string;
    whyThisStageExists: string;
    objective: string;
    whatPlayersMustDo: string[];
    requiredPuzzleIds: string[];
    requiredPuzzleTitles: string[];
    reveals: string;
  }>;
  puzzleLinks: Array<{
    puzzleId: string;
    puzzleTitle: string;
    storyRole: string;
    unlocks: string;
  }>;
};
type AuthUser = {
  id: string;
  name: string;
  email: string;
  provider: "local" | "google" | "facebook" | "github";
};
type SavedPlanSummary = {
  planId: string;
  name: string;
  approvedForBuild: boolean;
  sessionId: string;
  createdAt: string;
  updatedAt: string;
  themeName: string;
  puzzleCount: number;
};
type SavedPlanPayload = {
  planningInput: {
    playersConcurrent: number;
    participantsTotal: number;
    sessionDurationMinutes: number;
    environmentType: string;
    availableItems: string[];
    existingPuzzles: Array<{ name: string; link: string; roomPart: string }>;
  };
  themes: Theme[];
  selectedThemeId: string;
  puzzles: Puzzle[];
  suggestedAdditions: string[];
  storyPlan: StoryPlan | null;
  compatibilityPassed: boolean;
  exportContent: string;
};
const API_BASE = "";
const HISTORY_STORAGE_KEY = "escape-room-builder-input-history-v1";
const AUTH_STORAGE_KEY = "escape-room-builder-auth-v1";
type InputHistory = Record<string, string[]>;
const loadHistory = (): InputHistory => {
  try {
    const raw = window.localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as InputHistory;
  } catch {
    return {};
  }
};
const saveHistory = (history: InputHistory): void => {
  try {
    window.localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
  } catch {
    // Ignore localStorage failures.
  }
};

const deriveThemeFitFallback = (themeName: string, themeDescription: string, puzzle: Puzzle): string => {
  const themeText = `${themeName} ${themeDescription}`.toLowerCase();
  const objective = puzzle.objective.toLowerCase();
  const title = puzzle.title.toLowerCase();
  const isPrison = themeText.includes("prison") || themeText.includes("lockdown") || themeText.includes("cell");
  const isSciFi =
    themeText.includes("guardians") ||
    themeText.includes("galaxy") ||
    themeText.includes("space") ||
    themeText.includes("futur");

  if (isPrison && (title.includes("lock") || objective.includes("lock"))) {
    return `For "${themeName}", this fits naturally because lock-based progression matches prison security logic and makes the puzzle feel like part of a real containment system.`;
  }
  if (isSciFi && puzzle.category === "electronic") {
    return `For "${themeName}", this fits because electronic interaction mirrors futuristic systems and reinforces the high-tech worldbuilding.`;
  }
  if (puzzle.category === "physical") {
    return `For "${themeName}", this puzzle fits by using tactile mechanics that support believable in-world interactions.`;
  }
  if (puzzle.category === "logic") {
    return `For "${themeName}", this puzzle fits by turning narrative clues into deduction, keeping the story progression coherent.`;
  }
  return `For "${themeName}", this puzzle supports the theme through its narrative role and progression function.`;
};

export default function App() {
  const inputHistory = useMemo(() => loadHistory(), []);
  const initialAuth = useMemo(() => {
    try {
      const raw = window.localStorage.getItem(AUTH_STORAGE_KEY);
      if (!raw) return { authToken: "", authUser: null as AuthUser | null };
      const parsed = JSON.parse(raw) as { authToken?: string; authUser?: AuthUser | null };
      return { authToken: parsed.authToken ?? "", authUser: parsed.authUser ?? null };
    } catch {
      return { authToken: "", authUser: null as AuthUser | null };
    }
  }, []);

  const [themes, setThemes] = useState<Theme[]>([]);
  const [selectedThemeId, setSelectedThemeId] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [sessionId, setSessionId] = useState<string>("");
  const [playersConcurrent, setPlayersConcurrent] = useState<string>("4");
  const [participantsTotal, setParticipantsTotal] = useState<string>("6");
  const [sessionDurationMinutes, setSessionDurationMinutes] = useState<string>("45");
  const [environmentType, setEnvironmentType] = useState<string>("");
  const [availableItems, setAvailableItems] = useState<string>("");
  const [existingPuzzles, setExistingPuzzles] = useState<Array<{ name: string; link: string; roomPart: string }>>([]);
  const [existingPuzzleName, setExistingPuzzleName] = useState<string>("");
  const [existingPuzzleLink, setExistingPuzzleLink] = useState<string>("");
  const [existingPuzzleRoomPart, setExistingPuzzleRoomPart] = useState<string>("");
  const [puzzles, setPuzzles] = useState<Puzzle[]>([]);
  const [suggestedAdditions, setSuggestedAdditions] = useState<string[]>([]);
  const [storyPlan, setStoryPlan] = useState<StoryPlan | null>(null);
  const [compatibilityPassed, setCompatibilityPassed] = useState<boolean | null>(null);
  const [exportContent, setExportContent] = useState<string>("");
  const [customThemeName, setCustomThemeName] = useState<string>("");
  const [customThemeDescription, setCustomThemeDescription] = useState<string>("");
  const [authToken, setAuthToken] = useState<string>(initialAuth.authToken);
  const [authUser, setAuthUser] = useState<AuthUser | null>(initialAuth.authUser);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [authName, setAuthName] = useState<string>("");
  const [authEmail, setAuthEmail] = useState<string>("");
  const [authPassword, setAuthPassword] = useState<string>("");
  const [savedPlans, setSavedPlans] = useState<SavedPlanSummary[]>([]);
  const [approvedForBuild, setApprovedForBuild] = useState<boolean>(false);
  const [showPlanPicker, setShowPlanPicker] = useState<boolean>(Boolean(initialAuth.authUser));
  const [activePanel, setActivePanel] = useState<"plan" | "themes" | "saved" | "output">("plan");

  const selectedTheme = useMemo(
    () => themes.find((theme) => theme.id === selectedThemeId),
    [themes, selectedThemeId],
  );
  const rememberInput = (field: string, value: string): void => {
    const normalized = value.trim();
    if (!normalized) return;
    const current = loadHistory();
    const existing = current[field] ?? [];
    const next = [normalized, ...existing.filter((entry) => entry.toLowerCase() !== normalized.toLowerCase())].slice(
      0,
      12,
    );
    current[field] = next;
    saveHistory(current);
  };
  const selectedThemeName = selectedTheme?.name ?? "Selected Theme";
  const selectedThemeDescription = selectedTheme?.description ?? "";

  const persistAuth = (token: string, user: AuthUser | null): void => {
    setAuthToken(token);
    setAuthUser(user);
    setShowPlanPicker(Boolean(user));
    setActivePanel(Boolean(user) ? "saved" : "plan");
    try {
      if (!user || !token) {
        window.localStorage.removeItem(AUTH_STORAGE_KEY);
        return;
      }
      window.localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify({ authToken: token, authUser: user }));
    } catch {
      // Ignore storage errors; in-memory auth state still works for this session.
    }
  };
  const withAuthHeaders = (): HeadersInit => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${authToken}`,
  });
  const handleAuthExpired = (): void => {
    persistAuth("", null);
    setError("Your session expired. Please log in again.");
  };

  const handleSignup = async (): Promise<void> => {
    try {
      setError("");
      const response = await fetch(`${API_BASE}/api/auth/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: authName, email: authEmail, password: authPassword }),
      });
      const data = (await response.json()) as { authToken?: string; user?: AuthUser; error?: { message?: string } };
      if (!response.ok || !data.authToken || !data.user) {
        setError(data.error?.message ?? "Sign up failed.");
        return;
      }
      persistAuth(data.authToken, data.user);
    } catch {
      setError("Sign up failed. Check backend and try again.");
    }
  };

  const handleLogin = async (): Promise<void> => {
    try {
      setError("");
      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: authEmail, password: authPassword }),
      });
      const data = (await response.json()) as { authToken?: string; user?: AuthUser; error?: { message?: string } };
      if (!response.ok || !data.authToken || !data.user) {
        setError(data.error?.message ?? "Log in failed.");
        return;
      }
      persistAuth(data.authToken, data.user);
    } catch {
      setError("Log in failed. Check backend and try again.");
    }
  };

  const handleSocialAuth = (provider: "google" | "facebook" | "github"): void => {
    setError("");
    const returnTo = `${window.location.origin}${window.location.pathname}`;
    window.location.assign(
      `${API_BASE}/api/auth/oauth/${provider}/start?returnTo=${encodeURIComponent(returnTo)}`,
    );
  };

  useEffect(() => {
    const url = new URL(window.location.href);
    const callbackToken = url.searchParams.get("auth_token");
    const callbackUserRaw = url.searchParams.get("auth_user");
    if (!callbackToken || !callbackUserRaw) return;
    try {
      const callbackUser = JSON.parse(decodeURIComponent(callbackUserRaw)) as AuthUser;
      persistAuth(callbackToken, callbackUser);
      url.searchParams.delete("auth_token");
      url.searchParams.delete("auth_user");
      window.history.replaceState({}, document.title, `${url.pathname}${url.search}${url.hash}`);
    } catch {
      setError("Social sign in completed, but response could not be parsed.");
    }
  }, []);

  const requestThemes = async (
    activeSessionId: string,
    endpoint: "/api/themes/generate" | "/api/themes/refresh",
    currentThemes: Theme[],
  ): Promise<Theme[] | undefined> => {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body:
        endpoint === "/api/themes/refresh"
          ? JSON.stringify({ sessionId: activeSessionId, excludeThemeIds: currentThemes.map((theme) => theme.id) })
          : JSON.stringify({ sessionId: activeSessionId }),
    });
    const data = (await response.json()) as { themes?: Theme[]; error?: { message?: string } };
    if (!response.ok || !data.themes) {
      setError(data.error?.message ?? "Failed to load themes.");
      return undefined;
    }
    setThemes(data.themes);
    if (data.themes.length > 0) {
      setSelectedThemeId(data.themes[0].id);
    }
    return data.themes;
  };

  const requestPuzzles = async (activeSessionId: string, themeId: string): Promise<void> => {
    const response = await fetch(`${API_BASE}/api/puzzles/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: activeSessionId, themeId }),
    });
    const data = (await response.json()) as {
      puzzles?: Puzzle[];
      compatibilityPassed?: boolean;
      storyPlan?: StoryPlan;
      suggestedAdditions?: string[];
      error?: { message?: string };
    };
    if (!response.ok || !data.puzzles) {
      setError(data.error?.message ?? "Failed to generate puzzles.");
      return;
    }
    const basePuzzles = data.puzzles;
    const baseSuggestedAdditions = data.suggestedAdditions ?? [];
    const activeTheme = themes.find((theme) => theme.id === themeId);
    const aiEnhancement = await enhancePlanInBrowser({
      theme: activeTheme,
      environment: environmentType,
      availableItems,
      existingPuzzles,
      puzzles: basePuzzles,
      suggestedAdditions: baseSuggestedAdditions,
    });

    const enhancedPuzzles = aiEnhancement
      ? basePuzzles.map((puzzle) => {
          const match = aiEnhancement.puzzles.find((candidate) => candidate.id === puzzle.id);
          return match
            ? {
                ...puzzle,
                howItWorks: match.howItWorks || puzzle.howItWorks,
                themeFitReason: match.themeFitReason || puzzle.themeFitReason,
              }
            : puzzle;
        })
      : basePuzzles;

    const enhancedStoryPlan =
      aiEnhancement?.stages && data.storyPlan
        ? {
            ...data.storyPlan,
            stages: data.storyPlan.stages.map((stage) => {
              const match = aiEnhancement.stages?.find((candidate) => candidate.stage === stage.stage);
              return match
                ? {
                    ...stage,
                    whyThisStageExists: match.whyThisStageExists || stage.whyThisStageExists,
                  }
                : stage;
            }),
          }
        : data.storyPlan ?? null;

    setPuzzles(enhancedPuzzles);
    setCompatibilityPassed(Boolean(data.compatibilityPassed));
    setStoryPlan(enhancedStoryPlan);
    setSuggestedAdditions(aiEnhancement?.suggestedAdditions?.length ? aiEnhancement.suggestedAdditions : baseSuggestedAdditions);
  };

  const syncExistingPuzzles = async (
    activeSessionId: string,
    nextExistingPuzzles: Array<{ name: string; link: string; roomPart: string }>,
  ): Promise<void> => {
    await fetch(`${API_BASE}/api/planning/session/${activeSessionId}/existing-puzzles`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ existingPuzzles: nextExistingPuzzles }),
    });
  };

  const createSession = async (
    overrides?: { existingPuzzles?: Array<{ name: string; link: string; roomPart: string }> },
  ): Promise<string | undefined> => {
    // Start a new planning session from current form input.
    setError("");
    const payload = {
      playersConcurrent: Number(playersConcurrent),
      participantsTotal: Number(participantsTotal),
      sessionDurationMinutes: Number(sessionDurationMinutes),
      environmentType: environmentType.trim(),
      availableItems: availableItems
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
      existingPuzzles: overrides?.existingPuzzles ?? existingPuzzles,
    };

    if (
      !payload.playersConcurrent ||
      !payload.participantsTotal ||
      !payload.sessionDurationMinutes ||
      !payload.environmentType ||
      payload.availableItems.length === 0
    ) {
      setError("All planning inputs are required before generating themes.");
      return undefined;
    }

    try {
      const response = await fetch(`${API_BASE}/api/planning/session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { sessionId?: string; error?: { message?: string } };
      if (!response.ok || !data.sessionId) {
        setError(data.error?.message ?? "Failed to create session.");
        return undefined;
      }
      setSessionId(data.sessionId);
      rememberInput("environmentType", environmentType);
      rememberInput("availableItems", availableItems);
      setThemes([]);
      setSelectedThemeId("");
      setPuzzles([]);
      setSuggestedAdditions([]);
      setStoryPlan(null);
      setCompatibilityPassed(null);
      setExportContent("");
      setApprovedForBuild(false);
      await requestThemes(data.sessionId, "/api/themes/generate", []);
      return data.sessionId;
    } catch (_err) {
      setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
      return undefined;
    }
  };

  const ensureSession = async (): Promise<string | undefined> => {
    if (sessionId) return sessionId;
    return createSession();
  };

  const addExistingPuzzle = async () => {
    // Add user-provided puzzle metadata to the planning payload.
    setError("");
    const name = existingPuzzleName.trim();
    const link = existingPuzzleLink.trim();
    const roomPart = existingPuzzleRoomPart.trim();
    if (!name || !link || !roomPart) {
      setError("Provide existing puzzle name, details link, and room part.");
      return;
    }
    const nextExistingPuzzles = [...existingPuzzles, { name, link, roomPart }];
    setExistingPuzzles(nextExistingPuzzles);
    rememberInput("existingPuzzleName", name);
    rememberInput("existingPuzzleLink", link);
    rememberInput("existingPuzzleRoomPart", roomPart);
    setExistingPuzzleName("");
    setExistingPuzzleLink("");
    setExistingPuzzleRoomPart("");
    // Any interaction should initialize a planning session.
    let activeSessionId: string | undefined = sessionId;
    if (!activeSessionId) {
      activeSessionId = await createSession({ existingPuzzles: nextExistingPuzzles });
    }
    if (!activeSessionId) return;
    await syncExistingPuzzles(activeSessionId, nextExistingPuzzles);
    if (selectedThemeId) {
      await requestPuzzles(activeSessionId, selectedThemeId);
    }
  };

  const removeExistingPuzzle = async (index: number) => {
    const nextExistingPuzzles = existingPuzzles.filter((_, i) => i !== index);
    setExistingPuzzles(nextExistingPuzzles);
    const activeSessionId = await ensureSession();
    if (!activeSessionId) return;
    await syncExistingPuzzles(activeSessionId, nextExistingPuzzles);
    if (selectedThemeId) {
      await requestPuzzles(activeSessionId, selectedThemeId);
    }
  };

  const loadThemes = async (endpoint: "/api/themes/generate" | "/api/themes/refresh") => {
    // Load initial or refreshed theme options for the active session.
    setError("");
    const activeSessionId = await ensureSession();
    if (!activeSessionId) {
      return;
    }
    try {
      await requestThemes(activeSessionId, endpoint, themes);
    } catch (_err) {
      setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
    }
  };

  const generatePuzzles = async () => {
    // Generate puzzle set for selected theme.
    setError("");
    if (!selectedThemeId) {
      setError("Select a theme first.");
      return;
    }
    const activeSessionId = await ensureSession();
    if (!activeSessionId) return;
    try {
      await requestPuzzles(activeSessionId, selectedThemeId);
    } catch (_err) {
      setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
    }
  };

  const handleThemeSelect = async (themeId: string): Promise<void> => {
    setSelectedThemeId(themeId);
    if (!themeId.startsWith("th_custom_")) return;
    const activeSessionId = await ensureSession();
    if (!activeSessionId) return;
    await requestPuzzles(activeSessionId, themeId);
  };

  const addCustomTheme = async () => {
    // Persist a custom theme and auto-select it.
    setError("");
    if (!customThemeName.trim()) {
      setError("Enter a custom theme name.");
      return;
    }
    const activeSessionId = await ensureSession();
    if (!activeSessionId) return;
    try {
      const response = await fetch(`${API_BASE}/api/themes/custom`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: activeSessionId,
          name: customThemeName,
          description: customThemeDescription,
        }),
      });
      const data = (await response.json()) as { theme?: Theme; error?: { message?: string } };
      if (!response.ok || !data.theme) {
        setError(data.error?.message ?? "Failed to add custom theme.");
        return;
      }
      setThemes((current) => [data.theme as Theme, ...current.filter((theme) => theme.id !== data.theme?.id)]);
      setSelectedThemeId(data.theme.id);
      rememberInput("customThemeName", customThemeName);
      rememberInput("customThemeDescription", customThemeDescription);
      await requestPuzzles(activeSessionId, data.theme.id);
    } catch (_err) {
      setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
    }
  };

  const replacePuzzle = async (puzzleId: string) => {
    // Replace one puzzle while preserving the rest of the set.
    setError("");
    const activeSessionId = await ensureSession();
    if (!activeSessionId) return;
    try {
      const response = await fetch(`${API_BASE}/api/puzzles/${puzzleId}/replace`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: activeSessionId, themeId: selectedThemeId }),
      });
      const data = (await response.json()) as {
        replacedPuzzleId?: string;
        newPuzzle?: Puzzle;
        compatibilityPassed?: boolean;
        storyPlan?: StoryPlan;
        suggestedAdditions?: string[];
        error?: { message?: string };
      };
      if (!response.ok) {
        setError(data.error?.message ?? "No replacement available for that puzzle yet.");
        return;
      }
      if (!data.replacedPuzzleId || !data.newPuzzle) {
        setError("Replacement response was incomplete.");
        return;
      }
      const replacementPuzzle: Puzzle = data.newPuzzle;
      const nextPuzzles = puzzles.map((puzzle) =>
        puzzle.id === data.replacedPuzzleId ? replacementPuzzle : puzzle,
      );
      const activeTheme = themes.find((theme) => theme.id === selectedThemeId);
      const baseSuggestedAdditions = data.suggestedAdditions ?? suggestedAdditions;
      const aiEnhancement = await enhancePlanInBrowser({
        theme: activeTheme,
        environment: environmentType,
        availableItems,
        existingPuzzles,
        puzzles: nextPuzzles,
        suggestedAdditions: baseSuggestedAdditions,
      });
      const enhancedPuzzles = aiEnhancement
        ? nextPuzzles.map((puzzle) => {
            const match = aiEnhancement.puzzles.find((candidate) => candidate.id === puzzle.id);
            return match
              ? {
                  ...puzzle,
                  howItWorks: match.howItWorks || puzzle.howItWorks,
                  themeFitReason: match.themeFitReason || puzzle.themeFitReason,
                }
              : puzzle;
          })
        : nextPuzzles;
      const enhancedStoryPlan =
        aiEnhancement?.stages && data.storyPlan
          ? {
              ...data.storyPlan,
              stages: data.storyPlan.stages.map((stage) => {
                const match = aiEnhancement.stages?.find((candidate) => candidate.stage === stage.stage);
                return match
                  ? {
                      ...stage,
                      whyThisStageExists: match.whyThisStageExists || stage.whyThisStageExists,
                    }
                  : stage;
              }),
            }
          : data.storyPlan ?? null;
      setPuzzles(enhancedPuzzles);
      setCompatibilityPassed(Boolean(data.compatibilityPassed));
      setStoryPlan(enhancedStoryPlan);
      setSuggestedAdditions(aiEnhancement?.suggestedAdditions?.length ? aiEnhancement.suggestedAdditions : baseSuggestedAdditions);
    } catch (_err) {
      setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
    }
  };

  const exportPlan = async () => {
    // Request full markdown export for runbook/host usage.
    setError("");
    const activeSessionId = await ensureSession();
    if (!activeSessionId) return;
    try {
      const response = await fetch(`${API_BASE}/api/plans/${activeSessionId}/export`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ format: "markdown" }),
      });
      const data = (await response.json()) as { content?: string; error?: { message?: string } };
      if (!response.ok) {
        setError(data.error?.message ?? "Export failed.");
        return;
      }
      if (!data.content) {
        setError("Export response was incomplete.");
        return;
      }
      setExportContent(data.content);
    } catch (_err) {
      setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
    }
  };

  const refreshSavedPlans = async (): Promise<void> => {
    if (!authToken) return;
    const response = await fetch(`${API_BASE}/api/plans/saved`, {
      headers: { Authorization: `Bearer ${authToken}` },
    });
    if (response.status === 401) {
      handleAuthExpired();
      return;
    }
    const data = (await response.json()) as { plans?: SavedPlanSummary[]; error?: { message?: string } };
    if (!response.ok || !data.plans) {
      setError(data.error?.message ?? "Could not load saved plans.");
      return;
    }
    setSavedPlans(data.plans);
  };

  const saveCurrentPlan = async (): Promise<void> => {
    setError("");
    const activeSessionId = await ensureSession();
    if (!activeSessionId) return;
    if (!approvedForBuild) {
      setError("Approve this plan for build before saving it.");
      return;
    }
    try {
      const response = await fetch(`${API_BASE}/api/plans/${activeSessionId}/save`, {
        method: "POST",
        headers: withAuthHeaders(),
        body: JSON.stringify({
          name: `${selectedTheme?.name ?? "Untitled"} - ${new Date().toLocaleString()}`,
          approvedForBuild: true,
        }),
      });
      if (response.status === 401) {
        handleAuthExpired();
        return;
      }
      const data = (await response.json()) as { savedPlan?: SavedPlanSummary; error?: { message?: string } };
      if (!response.ok || !data.savedPlan) {
        setError(data.error?.message ?? "Failed to save plan.");
        return;
      }
      await refreshSavedPlans();
      setActivePanel("saved");
    } catch {
      setError("Could not save plan. Check backend and try again.");
    }
  };

  const loadSavedPlan = async (planId: string): Promise<void> => {
    setError("");
    try {
      const response = await fetch(`${API_BASE}/api/plans/saved/${planId}`, {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (response.status === 401) {
        handleAuthExpired();
        return;
      }
      const data = (await response.json()) as { savedPlan?: { sessionId: string; data: SavedPlanPayload }; error?: { message?: string } };
      if (!response.ok || !data.savedPlan) {
        setError(data.error?.message ?? "Failed to load saved plan.");
        return;
      }
      const payload = data.savedPlan.data;
      setSessionId(data.savedPlan.sessionId);
      setPlayersConcurrent(String(payload.planningInput.playersConcurrent));
      setParticipantsTotal(String(payload.planningInput.participantsTotal));
      setSessionDurationMinutes(String(payload.planningInput.sessionDurationMinutes));
      setEnvironmentType(payload.planningInput.environmentType);
      setAvailableItems(payload.planningInput.availableItems.join(", "));
      setExistingPuzzles(payload.planningInput.existingPuzzles);
      setThemes(payload.themes);
      setSelectedThemeId(payload.selectedThemeId);
      setPuzzles(payload.puzzles);
      setSuggestedAdditions(payload.suggestedAdditions);
      setStoryPlan(payload.storyPlan);
      setCompatibilityPassed(payload.compatibilityPassed);
      setExportContent(payload.exportContent ?? "");
      setApprovedForBuild(true);
      setShowPlanPicker(false);
      setActivePanel("output");
    } catch {
      setError("Could not load saved plan. Check backend and try again.");
    }
  };

  const deleteSavedPlan = async (planId: string): Promise<void> => {
    setError("");
    try {
      const response = await fetch(`${API_BASE}/api/plans/saved/${planId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (response.status === 401) {
        handleAuthExpired();
        return;
      }
      const data = (await response.json()) as { deletedPlanId?: string; error?: { message?: string } };
      if (!response.ok || !data.deletedPlanId) {
        setError(data.error?.message ?? "Failed to delete saved plan.");
        return;
      }
      setSavedPlans((current) => current.filter((plan) => plan.planId !== planId));
    } catch {
      setError("Could not delete saved plan. Check backend and try again.");
    }
  };

  useEffect(() => {
    if (!authToken || !authUser) {
      setSavedPlans([]);
      return;
    }
    void refreshSavedPlans();
  }, [authToken, authUser]);

  if (!authUser) {
    return (
      <main className="page-shell">
        <div className="auth-layout">
          <section className="hero auth-hero">
            <div className="hero-grid">
              <div>
                <p className="hero-chip">Immersive Planning Studio</p>
                <h1>Escape Room Builder</h1>
                <p>Sign up or log in to design and save room plans.</p>
                <ul className="auth-bullets">
                  <li>Generate cinematic room concepts quickly</li>
                  <li>Save approved plans for future builds</li>
                  <li>Export complete host-ready run sheets</li>
                </ul>
              </div>
              <div className="hero-visual" aria-hidden="true">
                <svg viewBox="0 0 220 140" role="img">
                  <rect x="10" y="14" width="200" height="112" rx="14" />
                  <circle cx="70" cy="70" r="26" />
                  <circle cx="70" cy="70" r="6" />
                  <path d="M96 70h68M122 58l12 12-12 12" />
                </svg>
              </div>
            </div>
          </section>
        {error ? <p className="error-banner">{error}</p> : null}
        <section className="card auth-card auth-panel">
          <div className="auth-mode-row">
            <button
              type="button"
              className={authMode === "login" ? "primary-btn auth-mode-btn" : "auth-mode-btn"}
              onClick={() => setAuthMode("login")}
            >
              Log In
            </button>
            <button
              type="button"
              className={authMode === "signup" ? "primary-btn auth-mode-btn" : "auth-mode-btn"}
              onClick={() => setAuthMode("signup")}
            >
              Sign Up
            </button>
          </div>
          <div className="form-grid">
            {authMode === "signup" ? (
              <label className="field-row">
                Name
                <input type="text" value={authName} onChange={(event) => setAuthName(event.target.value)} />
              </label>
            ) : null}
            <label className="field-row">
              Email
              <input type="email" value={authEmail} onChange={(event) => setAuthEmail(event.target.value)} />
            </label>
            <label className="field-row">
              Password
              <input type="password" value={authPassword} onChange={(event) => setAuthPassword(event.target.value)} />
            </label>
            <button type="button" className="primary-btn" onClick={authMode === "signup" ? handleSignup : handleLogin}>
              {authMode === "signup" ? "Create Account" : "Log In"}
            </button>
          </div>
          <p className="muted">
            Or continue with social sign-in:
          </p>
          <div className="social-auth-grid">
            <button type="button" className="social-btn social-google" onClick={() => handleSocialAuth("google")}>
              Continue with Google
            </button>
            <button type="button" className="social-btn social-facebook" onClick={() => handleSocialAuth("facebook")}>
              Continue with Facebook
            </button>
            <button type="button" className="social-btn social-github" onClick={() => handleSocialAuth("github")}>
              Continue with GitHub
            </button>
          </div>
        </section>
        </div>
      </main>
    );
  }

  return (
    // Main application layout and interactive sections.
    <main className="page-shell">
      <section className="hero">
        <div className="hero-grid">
          <div>
            <p className="hero-chip">Mission Control</p>
            <h1>Escape Room Builder</h1>
            <p>Design complete, theme-aligned rooms with story-driven progression.</p>
            <p className="muted">Signed in as {authUser.name} ({authUser.email})</p>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <svg viewBox="0 0 220 140" role="img">
              <rect x="10" y="14" width="200" height="112" rx="14" />
              <circle cx="70" cy="70" r="26" />
              <circle cx="70" cy="70" r="6" />
              <path d="M96 70h68M122 58l12 12-12 12" />
            </svg>
          </div>
        </div>
        <div className="button-row">
          <button type="button" onClick={() => persistAuth("", null)}>Log Out</button>
        </div>
      </section>
      <section className="card marketing-strip">
        <h2>Build Rooms Like a Studio Team</h2>
        <div className="features-grid">
          <article className="feature-item">
            <span className="feature-icon" aria-hidden="true">🗺️</span>
            <h3>Flow-First Planning</h3>
            <p>Move from concept to stage-based progression with clear reveal logic.</p>
          </article>
          <article className="feature-item">
            <span className="feature-icon" aria-hidden="true">🛠️</span>
            <h3>Build-Ready Details</h3>
            <p>Use wiring, parts, references, and story rationale to prep production quickly.</p>
          </article>
          <article className="feature-item">
            <span className="feature-icon" aria-hidden="true">📅</span>
            <h3>Session-Aware Design</h3>
            <p>Puzzle volume and complexity adjust to participant count and available minutes.</p>
          </article>
        </div>
      </section>
      <section className="card cta-strip">
        <h2>Booking-Style Quick Actions</h2>
        <div className="cta-grid">
          <article className="cta-card">
            <h3>Generate New Experience</h3>
            <p>Jump into planning inputs and produce a full room concept from scratch.</p>
            <button type="button" className="primary-btn" onClick={() => setActivePanel("plan")}>Start Planning</button>
          </article>
          <article className="cta-card">
            <h3>Resume Saved Build</h3>
            <p>Open your approved plans and continue execution without repeating setup.</p>
            <button type="button" onClick={() => setActivePanel("saved")}>Open Saved Plans</button>
          </article>
        </div>
      </section>
      <div className="workspace-layout">
        <aside className="workspace-sidebar card">
          <p className="muted">Workspace</p>
          <nav className="panel-nav" aria-label="Workspace sections">
            <button
              type="button"
              className={activePanel === "plan" ? "primary-btn" : ""}
              onClick={() => setActivePanel("plan")}
            >
              Planning
            </button>
            <button
              type="button"
              className={activePanel === "themes" ? "primary-btn" : ""}
              onClick={() => setActivePanel("themes")}
            >
              Themes
            </button>
            <button
              type="button"
              className={activePanel === "saved" ? "primary-btn" : ""}
              onClick={() => setActivePanel("saved")}
            >
              Saved Plans
            </button>
            <button
              type="button"
              className={activePanel === "output" ? "primary-btn" : ""}
              onClick={() => setActivePanel("output")}
            >
              Puzzle Output
            </button>
          </nav>
          <p className="muted">{sessionId ? "Planning session active" : "Planning session not started"}</p>
        </aside>
        <section className="workspace-content">
          {error ? <p className="error-banner">{error}</p> : null}
          {activePanel === "saved" && showPlanPicker ? (
        <section className="card">
          <h2>Welcome Back</h2>
          <p className="muted">Load a saved plan to continue where you left off, or start a new plan.</p>
          {savedPlans.length === 0 ? <p className="muted">No saved plans found for this account yet.</p> : null}
          {savedPlans.length > 0 ? (
            <ul className="list-compact">
              {savedPlans.map((plan) => (
                <li key={`picker-${plan.planId}`}>
                  <strong>{plan.name}</strong> - {plan.themeName} ({plan.puzzleCount} puzzles){" "}
                  <button type="button" className="secondary-btn" onClick={() => loadSavedPlan(plan.planId)}>
                    Load This Plan
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
          <div className="button-row">
            <button type="button" onClick={() => setShowPlanPicker(false)}>
              Start New Plan
            </button>
          </div>
        </section>
          ) : null}
          {activePanel === "plan" ? (
      <section className="card">
        <h2>Planning Input</h2>
        <div className="form-grid">
          <label>
            Players at one time
            <input
              type="number"
              min={1}
              value={playersConcurrent}
              onChange={(event) => setPlayersConcurrent(event.target.value)}
            />
          </label>
          <label>
            Total participants
            <input
              type="number"
              min={1}
              value={participantsTotal}
              onChange={(event) => setParticipantsTotal(event.target.value)}
            />
          </label>
          <label>
            Session duration (minutes)
            <input
              type="number"
              min={10}
              step={5}
              value={sessionDurationMinutes}
              onChange={(event) => setSessionDurationMinutes(event.target.value)}
            />
          </label>
          <label>
            Environment
            <input
              type="text"
              list="environment-history"
              value={environmentType}
              onChange={(event) => setEnvironmentType(event.target.value)}
              placeholder="Physical room where game is played (e.g., living room, garage)"
            />
          </label>
          <datalist id="environment-history">
            {(inputHistory.environmentType ?? []).map((entry) => (
              <option key={entry} value={entry} />
            ))}
          </datalist>
          <label>
            Available items (comma separated)
            <input
              type="text"
              list="items-history"
              value={availableItems}
              onChange={(event) => setAvailableItems(event.target.value)}
            />
          </label>
          <datalist id="items-history">
            {(inputHistory.availableItems ?? []).map((entry) => (
              <option key={entry} value={entry} />
            ))}
          </datalist>
          <p className="muted">
            Environment means the real physical room and existing objects where players will play.
            Theme is separate.
          </p>
          <div className="subcard">
            <p className="subcard-title"><strong>Existing puzzles to reuse</strong></p>
            <div className="form-grid">
              <label className="field-row">
                Puzzle name
                <input
                  type="text"
                  list="existing-puzzle-name-history"
                  value={existingPuzzleName}
                  onChange={(event) => setExistingPuzzleName(event.target.value)}
                  placeholder="Example: Telegraph Morse Box"
                />
              </label>
              <datalist id="existing-puzzle-name-history">
                {(inputHistory.existingPuzzleName ?? []).map((entry) => (
                  <option key={entry} value={entry} />
                ))}
              </datalist>
              <label className="field-row">
                Details link
                <input
                  type="url"
                  list="existing-puzzle-link-history"
                  value={existingPuzzleLink}
                  onChange={(event) => setExistingPuzzleLink(event.target.value)}
                  placeholder="https://..."
                />
              </label>
              <datalist id="existing-puzzle-link-history">
                {(inputHistory.existingPuzzleLink ?? []).map((entry) => (
                  <option key={entry} value={entry} />
                ))}
              </datalist>
              <label className="field-row">
                Room part / stage
                <input
                  type="text"
                  list="existing-puzzle-roompart-history"
                  value={existingPuzzleRoomPart}
                  onChange={(event) => setExistingPuzzleRoomPart(event.target.value)}
                  placeholder="Example: Intro, Mid-game, Finale"
                />
              </label>
              <datalist id="existing-puzzle-roompart-history">
                {(inputHistory.existingPuzzleRoomPart ?? []).map((entry) => (
                  <option key={entry} value={entry} />
                ))}
              </datalist>
              <button type="button" className="primary-btn" onClick={addExistingPuzzle}>
                Add Existing Puzzle
              </button>
            </div>
            {existingPuzzles.length > 0 ? (
              <ul className="list-compact">
                {existingPuzzles.map((puzzle, index) => (
                  <li key={`${puzzle.name}-${index}`}>
                    {puzzle.name} [{puzzle.roomPart}] -{" "}
                    <a href={puzzle.link} target="_blank" rel="noreferrer">
                      {puzzle.link}
                    </a>{" "}
                    <button type="button" onClick={() => removeExistingPuzzle(index)}>
                      Remove
                    </button>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>
        </div>
      </section>
          ) : null}

          {activePanel === "plan" ? (
      <section className="card">
        <h2>Use Your Own Theme</h2>
        <div className="form-grid">
          <label>
            Theme name
            <input
              type="text"
              list="custom-theme-name-history"
              value={customThemeName}
              onChange={(event) => setCustomThemeName(event.target.value)}
              placeholder="Example: Ancient Temple Lockdown"
            />
          </label>
          <datalist id="custom-theme-name-history">
            {(inputHistory.customThemeName ?? []).map((entry) => (
              <option key={entry} value={entry} />
            ))}
          </datalist>
          <label>
            Theme description (optional)
            <input
              type="text"
              list="custom-theme-description-history"
              value={customThemeDescription}
              onChange={(event) => setCustomThemeDescription(event.target.value)}
              placeholder="Brief setup for puzzle generation context"
            />
          </label>
          <datalist id="custom-theme-description-history">
            {(inputHistory.customThemeDescription ?? []).map((entry) => (
              <option key={entry} value={entry} />
            ))}
          </datalist>
          <button type="button" className="primary-btn" onClick={addCustomTheme}>
            Add and Select Custom Theme
          </button>
        </div>
      </section>
          ) : null}

          {activePanel === "themes" ? (
      <div className="button-row">
        <button type="button" onClick={() => loadThemes("/api/themes/generate")}>
          Generate Themes
        </button>
        <button type="button" onClick={() => loadThemes("/api/themes/refresh")}>
          Refresh Themes
        </button>
        <button type="button" onClick={generatePuzzles} disabled={!selectedThemeId}>
          Generate Puzzles
        </button>
        <button type="button" onClick={exportPlan}>
          Export Plan
        </button>
        <button type="button" onClick={saveCurrentPlan}>
          Save Plan
        </button>
        <button
          type="button"
          className={approvedForBuild ? "primary-btn" : ""}
          onClick={() => setApprovedForBuild((current) => !current)}
        >
          {approvedForBuild ? "Approved for Build" : "Mark Approved for Build"}
        </button>
      </div>
          ) : null}

          {activePanel === "saved" ? (
      <section className="card">
        <h2>Saved Plans</h2>
        {savedPlans.length === 0 ? (
          <p className="muted">No saved plans yet for this account.</p>
        ) : (
          <ul className="list-compact">
            {savedPlans.map((plan) => (
              <li key={plan.planId}>
                <strong>{plan.name}</strong> - {plan.themeName} ({plan.puzzleCount} puzzles){" "}
                {plan.approvedForBuild ? <span className="status-pass">Approved</span> : <span className="muted">Not approved</span>}{" "}
                <button type="button" className="secondary-btn" onClick={() => loadSavedPlan(plan.planId)}>
                  Load
                </button>
                <button type="button" className="secondary-btn" onClick={() => deleteSavedPlan(plan.planId)}>
                  Delete
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
          ) : null}

          {activePanel === "themes" ? (
      <ul className="card list-compact">
        {themes.map((theme) => (
          <li key={theme.id}>
            <label>
              <input
                type="radio"
                value={theme.id}
                checked={selectedThemeId === theme.id}
                onChange={() => {
                  void handleThemeSelect(theme.id);
                }}
              />
              <strong> {theme.name}</strong> - {theme.description}
            </label>
          </li>
        ))}
      </ul>
          ) : null}

          {activePanel === "themes" && selectedTheme ? (
        <section className="card">
          <h2>Selected Theme</h2>
          <p>{selectedTheme.name}</p>
        </section>
          ) : null}

          {activePanel === "output" && suggestedAdditions.length > 0 ? (
        <section className="card">
          <h2>Suggested Elements to Add (If Needed)</h2>
          <ul className="list-compact">
            {suggestedAdditions.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </section>
          ) : null}

          {activePanel === "output" && puzzles.length > 0 ? (
        <section className="card">
          <h2>Puzzle Set</h2>
          <p className={compatibilityPassed ? "status-pass" : "status-fail"}>
            Theme compatibility checks passed: {compatibilityPassed ? "Yes" : "No"}
          </p>
          <ul className="list-compact">
            {puzzles.map((puzzle) => (
              <li key={puzzle.id}>
                <strong>{puzzle.title}</strong> ({puzzle.category}, {puzzle.difficulty}) - {puzzle.objective}
                <p className="inline-space">
                  <strong>How it works:</strong> {puzzle.howItWorks}
                </p>
                <p className="inline-space">
                  <strong>Why this fits the theme:</strong>{" "}
                  {puzzle.themeFitReason ??
                    deriveThemeFitFallback(selectedThemeName, selectedThemeDescription, puzzle)}
                </p>
                <p className="inline-space"><strong>References:</strong></p>
                <ul className="list-compact">
                  {(puzzle.referenceLinks ?? []).map((ref) => (
                    <li key={ref.url}>
                      <a href={ref.url} target="_blank" rel="noreferrer">
                        {ref.title}
                      </a>
                    </li>
                  ))}
                </ul>
                <button
                  type="button"
                  className="secondary-btn"
                  onClick={() => replacePuzzle(puzzle.id)}
                >
                  Replace
                </button>
                {puzzle.category === "electronic" && puzzle.electronicDetails ? (
                  <div className="subcard">
                    <p><strong>Parts</strong></p>
                    <ul className="list-compact">
                      {puzzle.electronicDetails.parts.map((part) => (
                        <li key={part}>{part}</li>
                      ))}
                    </ul>
                    <p><strong>Wiring Diagram</strong></p>
                    <img
                      src={`data:image/svg+xml;utf8,${encodeURIComponent(puzzle.electronicDetails.wiringDiagramSvg)}`}
                      alt={`${puzzle.title} wiring diagram`}
                      className="diagram-img"
                    />
                    <ul className="list-compact">
                      {puzzle.electronicDetails.wiringDiagram.map((wire) => (
                        <li key={wire}>{wire}</li>
                      ))}
                    </ul>
                    <p><strong>Build Steps</strong></p>
                    <ol>
                      {puzzle.electronicDetails.buildSteps.map((step) => (
                        <li key={step}>{step}</li>
                      ))}
                    </ol>
                    <p><strong>Arduino Code</strong></p>
                    <pre className="code-block">
                      {puzzle.electronicDetails.arduinoCode}
                    </pre>
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
        </section>
          ) : null}

          {activePanel === "output" && storyPlan ? (
        <section className="card">
          <h2>Storyline and Progression</h2>
          <p>
            <strong>Situation:</strong> {storyPlan.situation}
          </p>
          <p>
            <strong>Premise:</strong> {storyPlan.premise}
          </p>
          <p>
            <strong>Mission objective:</strong> {storyPlan.missionObjective}
          </p>
          <p>
            <strong>Progression rule:</strong> {storyPlan.progressionRule}
          </p>
          <h3>Stage Flow</h3>
          <ul className="list-compact">
            {storyPlan.stages.map((stage) => (
              <li key={stage.stage}>
                <strong>{stage.title}</strong> - {stage.storyBeat}
                <br />
                Why: {stage.whyThisStageExists}
                <br />
                Objective: {stage.objective}
                <br />
                Required: {stage.requiredPuzzleTitles.join(" and ")}
                <br />
                Must do:
                <ul className="list-compact">
                  {stage.whatPlayersMustDo.map((step) => (
                    <li key={`${stage.stage}-${step}`}>{step}</li>
                  ))}
                </ul>
                Reveals: {stage.reveals}
              </li>
            ))}
          </ul>
          <h3>Puzzle to Story Mapping</h3>
          <ul className="list-compact">
            {storyPlan.puzzleLinks.map((link) => (
              <li key={link.puzzleId}>
                <strong>{link.puzzleTitle}</strong> - {link.storyRole}. {link.unlocks}
              </li>
            ))}
          </ul>
        </section>
          ) : null}

          {activePanel === "output" && exportContent ? (
        <section className="card">
          <h2>Export Output</h2>
          <pre className="code-block">{exportContent}</pre>
        </section>
          ) : null}
        </section>
      </div>
    </main>
  );
}

