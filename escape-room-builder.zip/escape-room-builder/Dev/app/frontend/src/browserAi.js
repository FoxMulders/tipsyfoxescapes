const extractJson = (text) => {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start < 0 || end <= start)
        return text;
    return text.slice(start, end + 1);
};
export const enhancePlanInBrowser = async (input) => {
    if (!window.ai?.languageModel?.create)
        return null;
    const model = await window.ai.languageModel.create();
    try {
        const prompt = [
            "You are an escape room design assistant.",
            "Return ONLY JSON with this exact shape:",
            '{"puzzles":[{"id":"...","howItWorks":"...","themeFitReason":"..."}],"stages":[{"stage":1,"whyThisStageExists":"..."}],"suggestedAdditions":["..."]}',
            "Rules:",
            "- Keep each howItWorks practical and concise (1-2 sentences).",
            "- Theme-fit rationale must explicitly reference the actual theme context.",
            "- Stage whyThisStageExists must be specific per stage and must not repeat generic phrasing.",
            "- Suggested additions should reflect the physical room/environment constraints.",
            "Input:",
            JSON.stringify(input),
        ].join("\n");
        const raw = await model.prompt(prompt);
        const parsed = JSON.parse(extractJson(raw));
        if (!Array.isArray(parsed.puzzles) || !Array.isArray(parsed.suggestedAdditions))
            return null;
        return parsed;
    }
    catch {
        return null;
    }
    finally {
        model.destroy?.();
    }
};
