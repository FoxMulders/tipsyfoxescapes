type Theme = { id: string; name: string; description: string };
type Puzzle = {
  id: string;
  category: "logic" | "physical" | "electronic";
  title: string;
  objective: string;
  howItWorks: string;
  themeFitReason?: string;
  referenceLinks: { title: string; url: string }[];
  solveSteps: string[];
  difficulty: "easy" | "medium" | "hard";
};

type ExistingPuzzle = { name: string; link: string; roomPart: string };

type BrowserEnhancementInput = {
  theme: Theme | undefined;
  environment: string;
  availableItems: string;
  existingPuzzles: ExistingPuzzle[];
  puzzles: Puzzle[];
  suggestedAdditions: string[];
};

type BrowserEnhancementOutput = {
  puzzles: Array<{
    id: string;
    howItWorks: string;
    themeFitReason: string;
  }>;
  stages?: Array<{
    stage: number;
    whyThisStageExists: string;
  }>;
  suggestedAdditions: string[];
};

declare global {
  interface Window {
    ai?: {
      languageModel?: {
        create?: () => Promise<{
          prompt: (text: string) => Promise<string>;
          destroy?: () => void;
        }>;
      };
    };
  }
}

const extractJson = (text: string): string => {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) return text;
  return text.slice(start, end + 1);
};

export const enhancePlanInBrowser = async (
  input: BrowserEnhancementInput,
): Promise<BrowserEnhancementOutput | null> => {
  if (!window.ai?.languageModel?.create) return null;

  const model = await window.ai.languageModel.create();
  try {
    const prompt = [
      "You are an escape room design assistant.",
      "Return ONLY JSON with this exact shape:",
      '{"puzzles":[{"id":"...","howItWorks":"...","themeFitReason":"..."}],"stages":[{"stage":1,"whyThisStageExists":"..."}],"suggestedAdditions":["..."]}',
      "Rules:",
      "- Keep each howItWorks practical and concise (1-2 sentences).",
      "- Theme-fit rationale must explicitly reference the actual theme context.",
      "- Stage whyThisStageExists must be specific per stage and must not repeat generic phrasing.",
      "- Suggested additions should reflect the physical room/environment constraints.",
      "Input:",
      JSON.stringify(input),
    ].join("\n");

    const raw = await model.prompt(prompt);
    const parsed = JSON.parse(extractJson(raw)) as BrowserEnhancementOutput;
    if (!Array.isArray(parsed.puzzles) || !Array.isArray(parsed.suggestedAdditions)) return null;
    return parsed;
  } catch {
    return null;
  } finally {
    model.destroy?.();
  }
};

