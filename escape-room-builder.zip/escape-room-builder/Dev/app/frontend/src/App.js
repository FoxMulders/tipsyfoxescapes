import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useMemo, useState } from "react";
import "./App.css";
import { enhancePlanInBrowser } from "./browserAi";
const API_BASE = "";
const HISTORY_STORAGE_KEY = "escape-room-builder-input-history-v1";
const AUTH_STORAGE_KEY = "escape-room-builder-auth-v1";
const loadHistory = () => {
    try {
        const raw = window.localStorage.getItem(HISTORY_STORAGE_KEY);
        if (!raw)
            return {};
        return JSON.parse(raw);
    }
    catch {
        return {};
    }
};
const saveHistory = (history) => {
    try {
        window.localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
    }
    catch {
        // Ignore localStorage failures.
    }
};
const deriveThemeFitFallback = (themeName, themeDescription, puzzle) => {
    const themeText = `${themeName} ${themeDescription}`.toLowerCase();
    const objective = puzzle.objective.toLowerCase();
    const title = puzzle.title.toLowerCase();
    const isPrison = themeText.includes("prison") || themeText.includes("lockdown") || themeText.includes("cell");
    const isSciFi = themeText.includes("guardians") ||
        themeText.includes("galaxy") ||
        themeText.includes("space") ||
        themeText.includes("futur");
    if (isPrison && (title.includes("lock") || objective.includes("lock"))) {
        return `For "${themeName}", this fits naturally because lock-based progression matches prison security logic and makes the puzzle feel like part of a real containment system.`;
    }
    if (isSciFi && puzzle.category === "electronic") {
        return `For "${themeName}", this fits because electronic interaction mirrors futuristic systems and reinforces the high-tech worldbuilding.`;
    }
    if (puzzle.category === "physical") {
        return `For "${themeName}", this puzzle fits by using tactile mechanics that support believable in-world interactions.`;
    }
    if (puzzle.category === "logic") {
        return `For "${themeName}", this puzzle fits by turning narrative clues into deduction, keeping the story progression coherent.`;
    }
    return `For "${themeName}", this puzzle supports the theme through its narrative role and progression function.`;
};
export default function App() {
    const inputHistory = useMemo(() => loadHistory(), []);
    const initialAuth = useMemo(() => {
        try {
            const raw = window.localStorage.getItem(AUTH_STORAGE_KEY);
            if (!raw)
                return { authToken: "", authUser: null };
            const parsed = JSON.parse(raw);
            return { authToken: parsed.authToken ?? "", authUser: parsed.authUser ?? null };
        }
        catch {
            return { authToken: "", authUser: null };
        }
    }, []);
    const [themes, setThemes] = useState([]);
    const [selectedThemeId, setSelectedThemeId] = useState("");
    const [error, setError] = useState("");
    const [sessionId, setSessionId] = useState("");
    const [playersConcurrent, setPlayersConcurrent] = useState("4");
    const [participantsTotal, setParticipantsTotal] = useState("6");
    const [sessionDurationMinutes, setSessionDurationMinutes] = useState("45");
    const [environmentType, setEnvironmentType] = useState("");
    const [availableItems, setAvailableItems] = useState("");
    const [existingPuzzles, setExistingPuzzles] = useState([]);
    const [existingPuzzleName, setExistingPuzzleName] = useState("");
    const [existingPuzzleLink, setExistingPuzzleLink] = useState("");
    const [existingPuzzleRoomPart, setExistingPuzzleRoomPart] = useState("");
    const [puzzles, setPuzzles] = useState([]);
    const [suggestedAdditions, setSuggestedAdditions] = useState([]);
    const [storyPlan, setStoryPlan] = useState(null);
    const [compatibilityPassed, setCompatibilityPassed] = useState(null);
    const [exportContent, setExportContent] = useState("");
    const [customThemeName, setCustomThemeName] = useState("");
    const [customThemeDescription, setCustomThemeDescription] = useState("");
    const [authToken, setAuthToken] = useState(initialAuth.authToken);
    const [authUser, setAuthUser] = useState(initialAuth.authUser);
    const [authMode, setAuthMode] = useState("login");
    const [authName, setAuthName] = useState("");
    const [authEmail, setAuthEmail] = useState("");
    const [authPassword, setAuthPassword] = useState("");
    const [savedPlans, setSavedPlans] = useState([]);
    const [approvedForBuild, setApprovedForBuild] = useState(false);
    const [showPlanPicker, setShowPlanPicker] = useState(Boolean(initialAuth.authUser));
    const [activePanel, setActivePanel] = useState("plan");
    const selectedTheme = useMemo(() => themes.find((theme) => theme.id === selectedThemeId), [themes, selectedThemeId]);
    const rememberInput = (field, value) => {
        const normalized = value.trim();
        if (!normalized)
            return;
        const current = loadHistory();
        const existing = current[field] ?? [];
        const next = [normalized, ...existing.filter((entry) => entry.toLowerCase() !== normalized.toLowerCase())].slice(0, 12);
        current[field] = next;
        saveHistory(current);
    };
    const selectedThemeName = selectedTheme?.name ?? "Selected Theme";
    const selectedThemeDescription = selectedTheme?.description ?? "";
    const persistAuth = (token, user) => {
        setAuthToken(token);
        setAuthUser(user);
        setShowPlanPicker(Boolean(user));
        setActivePanel(Boolean(user) ? "saved" : "plan");
        try {
            if (!user || !token) {
                window.localStorage.removeItem(AUTH_STORAGE_KEY);
                return;
            }
            window.localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify({ authToken: token, authUser: user }));
        }
        catch {
            // Ignore storage errors; in-memory auth state still works for this session.
        }
    };
    const withAuthHeaders = () => ({
        "Content-Type": "application/json",
        Authorization: `Bearer ${authToken}`,
    });
    const handleAuthExpired = () => {
        persistAuth("", null);
        setError("Your session expired. Please log in again.");
    };
    const handleSignup = async () => {
        try {
            setError("");
            const response = await fetch(`${API_BASE}/api/auth/signup`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name: authName, email: authEmail, password: authPassword }),
            });
            const data = (await response.json());
            if (!response.ok || !data.authToken || !data.user) {
                setError(data.error?.message ?? "Sign up failed.");
                return;
            }
            persistAuth(data.authToken, data.user);
        }
        catch {
            setError("Sign up failed. Check backend and try again.");
        }
    };
    const handleLogin = async () => {
        try {
            setError("");
            const response = await fetch(`${API_BASE}/api/auth/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email: authEmail, password: authPassword }),
            });
            const data = (await response.json());
            if (!response.ok || !data.authToken || !data.user) {
                setError(data.error?.message ?? "Log in failed.");
                return;
            }
            persistAuth(data.authToken, data.user);
        }
        catch {
            setError("Log in failed. Check backend and try again.");
        }
    };
    const handleSocialAuth = (provider) => {
        setError("");
        const returnTo = `${window.location.origin}${window.location.pathname}`;
        window.location.assign(`${API_BASE}/api/auth/oauth/${provider}/start?returnTo=${encodeURIComponent(returnTo)}`);
    };
    useEffect(() => {
        const url = new URL(window.location.href);
        const callbackToken = url.searchParams.get("auth_token");
        const callbackUserRaw = url.searchParams.get("auth_user");
        if (!callbackToken || !callbackUserRaw)
            return;
        try {
            const callbackUser = JSON.parse(decodeURIComponent(callbackUserRaw));
            persistAuth(callbackToken, callbackUser);
            url.searchParams.delete("auth_token");
            url.searchParams.delete("auth_user");
            window.history.replaceState({}, document.title, `${url.pathname}${url.search}${url.hash}`);
        }
        catch {
            setError("Social sign in completed, but response could not be parsed.");
        }
    }, []);
    const requestThemes = async (activeSessionId, endpoint, currentThemes) => {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: endpoint === "/api/themes/refresh"
                ? JSON.stringify({ sessionId: activeSessionId, excludeThemeIds: currentThemes.map((theme) => theme.id) })
                : JSON.stringify({ sessionId: activeSessionId }),
        });
        const data = (await response.json());
        if (!response.ok || !data.themes) {
            setError(data.error?.message ?? "Failed to load themes.");
            return undefined;
        }
        setThemes(data.themes);
        if (data.themes.length > 0) {
            setSelectedThemeId(data.themes[0].id);
        }
        return data.themes;
    };
    const requestPuzzles = async (activeSessionId, themeId) => {
        const response = await fetch(`${API_BASE}/api/puzzles/generate`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ sessionId: activeSessionId, themeId }),
        });
        const data = (await response.json());
        if (!response.ok || !data.puzzles) {
            setError(data.error?.message ?? "Failed to generate puzzles.");
            return;
        }
        const basePuzzles = data.puzzles;
        const baseSuggestedAdditions = data.suggestedAdditions ?? [];
        const activeTheme = themes.find((theme) => theme.id === themeId);
        const aiEnhancement = await enhancePlanInBrowser({
            theme: activeTheme,
            environment: environmentType,
            availableItems,
            existingPuzzles,
            puzzles: basePuzzles,
            suggestedAdditions: baseSuggestedAdditions,
        });
        const enhancedPuzzles = aiEnhancement
            ? basePuzzles.map((puzzle) => {
                const match = aiEnhancement.puzzles.find((candidate) => candidate.id === puzzle.id);
                return match
                    ? {
                        ...puzzle,
                        howItWorks: match.howItWorks || puzzle.howItWorks,
                        themeFitReason: match.themeFitReason || puzzle.themeFitReason,
                    }
                    : puzzle;
            })
            : basePuzzles;
        const enhancedStoryPlan = aiEnhancement?.stages && data.storyPlan
            ? {
                ...data.storyPlan,
                stages: data.storyPlan.stages.map((stage) => {
                    const match = aiEnhancement.stages?.find((candidate) => candidate.stage === stage.stage);
                    return match
                        ? {
                            ...stage,
                            whyThisStageExists: match.whyThisStageExists || stage.whyThisStageExists,
                        }
                        : stage;
                }),
            }
            : data.storyPlan ?? null;
        setPuzzles(enhancedPuzzles);
        setCompatibilityPassed(Boolean(data.compatibilityPassed));
        setStoryPlan(enhancedStoryPlan);
        setSuggestedAdditions(aiEnhancement?.suggestedAdditions?.length ? aiEnhancement.suggestedAdditions : baseSuggestedAdditions);
    };
    const syncExistingPuzzles = async (activeSessionId, nextExistingPuzzles) => {
        await fetch(`${API_BASE}/api/planning/session/${activeSessionId}/existing-puzzles`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ existingPuzzles: nextExistingPuzzles }),
        });
    };
    const createSession = async (overrides) => {
        // Start a new planning session from current form input.
        setError("");
        const payload = {
            playersConcurrent: Number(playersConcurrent),
            participantsTotal: Number(participantsTotal),
            sessionDurationMinutes: Number(sessionDurationMinutes),
            environmentType: environmentType.trim(),
            availableItems: availableItems
                .split(",")
                .map((item) => item.trim())
                .filter(Boolean),
            existingPuzzles: overrides?.existingPuzzles ?? existingPuzzles,
        };
        if (!payload.playersConcurrent ||
            !payload.participantsTotal ||
            !payload.sessionDurationMinutes ||
            !payload.environmentType ||
            payload.availableItems.length === 0) {
            setError("All planning inputs are required before generating themes.");
            return undefined;
        }
        try {
            const response = await fetch(`${API_BASE}/api/planning/session`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            const data = (await response.json());
            if (!response.ok || !data.sessionId) {
                setError(data.error?.message ?? "Failed to create session.");
                return undefined;
            }
            setSessionId(data.sessionId);
            rememberInput("environmentType", environmentType);
            rememberInput("availableItems", availableItems);
            setThemes([]);
            setSelectedThemeId("");
            setPuzzles([]);
            setSuggestedAdditions([]);
            setStoryPlan(null);
            setCompatibilityPassed(null);
            setExportContent("");
            setApprovedForBuild(false);
            await requestThemes(data.sessionId, "/api/themes/generate", []);
            return data.sessionId;
        }
        catch (_err) {
            setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
            return undefined;
        }
    };
    const ensureSession = async () => {
        if (sessionId)
            return sessionId;
        return createSession();
    };
    const addExistingPuzzle = async () => {
        // Add user-provided puzzle metadata to the planning payload.
        setError("");
        const name = existingPuzzleName.trim();
        const link = existingPuzzleLink.trim();
        const roomPart = existingPuzzleRoomPart.trim();
        if (!name || !link || !roomPart) {
            setError("Provide existing puzzle name, details link, and room part.");
            return;
        }
        const nextExistingPuzzles = [...existingPuzzles, { name, link, roomPart }];
        setExistingPuzzles(nextExistingPuzzles);
        rememberInput("existingPuzzleName", name);
        rememberInput("existingPuzzleLink", link);
        rememberInput("existingPuzzleRoomPart", roomPart);
        setExistingPuzzleName("");
        setExistingPuzzleLink("");
        setExistingPuzzleRoomPart("");
        // Any interaction should initialize a planning session.
        let activeSessionId = sessionId;
        if (!activeSessionId) {
            activeSessionId = await createSession({ existingPuzzles: nextExistingPuzzles });
        }
        if (!activeSessionId)
            return;
        await syncExistingPuzzles(activeSessionId, nextExistingPuzzles);
        if (selectedThemeId) {
            await requestPuzzles(activeSessionId, selectedThemeId);
        }
    };
    const removeExistingPuzzle = async (index) => {
        const nextExistingPuzzles = existingPuzzles.filter((_, i) => i !== index);
        setExistingPuzzles(nextExistingPuzzles);
        const activeSessionId = await ensureSession();
        if (!activeSessionId)
            return;
        await syncExistingPuzzles(activeSessionId, nextExistingPuzzles);
        if (selectedThemeId) {
            await requestPuzzles(activeSessionId, selectedThemeId);
        }
    };
    const loadThemes = async (endpoint) => {
        // Load initial or refreshed theme options for the active session.
        setError("");
        const activeSessionId = await ensureSession();
        if (!activeSessionId) {
            return;
        }
        try {
            await requestThemes(activeSessionId, endpoint, themes);
        }
        catch (_err) {
            setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
        }
    };
    const generatePuzzles = async () => {
        // Generate puzzle set for selected theme.
        setError("");
        if (!selectedThemeId) {
            setError("Select a theme first.");
            return;
        }
        const activeSessionId = await ensureSession();
        if (!activeSessionId)
            return;
        try {
            await requestPuzzles(activeSessionId, selectedThemeId);
        }
        catch (_err) {
            setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
        }
    };
    const handleThemeSelect = async (themeId) => {
        setSelectedThemeId(themeId);
        if (!themeId.startsWith("th_custom_"))
            return;
        const activeSessionId = await ensureSession();
        if (!activeSessionId)
            return;
        await requestPuzzles(activeSessionId, themeId);
    };
    const addCustomTheme = async () => {
        // Persist a custom theme and auto-select it.
        setError("");
        if (!customThemeName.trim()) {
            setError("Enter a custom theme name.");
            return;
        }
        const activeSessionId = await ensureSession();
        if (!activeSessionId)
            return;
        try {
            const response = await fetch(`${API_BASE}/api/themes/custom`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    sessionId: activeSessionId,
                    name: customThemeName,
                    description: customThemeDescription,
                }),
            });
            const data = (await response.json());
            if (!response.ok || !data.theme) {
                setError(data.error?.message ?? "Failed to add custom theme.");
                return;
            }
            setThemes((current) => [data.theme, ...current.filter((theme) => theme.id !== data.theme?.id)]);
            setSelectedThemeId(data.theme.id);
            rememberInput("customThemeName", customThemeName);
            rememberInput("customThemeDescription", customThemeDescription);
            await requestPuzzles(activeSessionId, data.theme.id);
        }
        catch (_err) {
            setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
        }
    };
    const replacePuzzle = async (puzzleId) => {
        // Replace one puzzle while preserving the rest of the set.
        setError("");
        const activeSessionId = await ensureSession();
        if (!activeSessionId)
            return;
        try {
            const response = await fetch(`${API_BASE}/api/puzzles/${puzzleId}/replace`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ sessionId: activeSessionId, themeId: selectedThemeId }),
            });
            const data = (await response.json());
            if (!response.ok) {
                setError(data.error?.message ?? "No replacement available for that puzzle yet.");
                return;
            }
            if (!data.replacedPuzzleId || !data.newPuzzle) {
                setError("Replacement response was incomplete.");
                return;
            }
            const replacementPuzzle = data.newPuzzle;
            const nextPuzzles = puzzles.map((puzzle) => puzzle.id === data.replacedPuzzleId ? replacementPuzzle : puzzle);
            const activeTheme = themes.find((theme) => theme.id === selectedThemeId);
            const baseSuggestedAdditions = data.suggestedAdditions ?? suggestedAdditions;
            const aiEnhancement = await enhancePlanInBrowser({
                theme: activeTheme,
                environment: environmentType,
                availableItems,
                existingPuzzles,
                puzzles: nextPuzzles,
                suggestedAdditions: baseSuggestedAdditions,
            });
            const enhancedPuzzles = aiEnhancement
                ? nextPuzzles.map((puzzle) => {
                    const match = aiEnhancement.puzzles.find((candidate) => candidate.id === puzzle.id);
                    return match
                        ? {
                            ...puzzle,
                            howItWorks: match.howItWorks || puzzle.howItWorks,
                            themeFitReason: match.themeFitReason || puzzle.themeFitReason,
                        }
                        : puzzle;
                })
                : nextPuzzles;
            const enhancedStoryPlan = aiEnhancement?.stages && data.storyPlan
                ? {
                    ...data.storyPlan,
                    stages: data.storyPlan.stages.map((stage) => {
                        const match = aiEnhancement.stages?.find((candidate) => candidate.stage === stage.stage);
                        return match
                            ? {
                                ...stage,
                                whyThisStageExists: match.whyThisStageExists || stage.whyThisStageExists,
                            }
                            : stage;
                    }),
                }
                : data.storyPlan ?? null;
            setPuzzles(enhancedPuzzles);
            setCompatibilityPassed(Boolean(data.compatibilityPassed));
            setStoryPlan(enhancedStoryPlan);
            setSuggestedAdditions(aiEnhancement?.suggestedAdditions?.length ? aiEnhancement.suggestedAdditions : baseSuggestedAdditions);
        }
        catch (_err) {
            setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
        }
    };
    const exportPlan = async () => {
        // Request full markdown export for runbook/host usage.
        setError("");
        const activeSessionId = await ensureSession();
        if (!activeSessionId)
            return;
        try {
            const response = await fetch(`${API_BASE}/api/plans/${activeSessionId}/export`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ format: "markdown" }),
            });
            const data = (await response.json());
            if (!response.ok) {
                setError(data.error?.message ?? "Export failed.");
                return;
            }
            if (!data.content) {
                setError("Export response was incomplete.");
                return;
            }
            setExportContent(data.content);
        }
        catch (_err) {
            setError("Cannot reach backend API. Make sure backend is running in Dev/app/backend with npm run dev.");
        }
    };
    const refreshSavedPlans = async () => {
        if (!authToken)
            return;
        const response = await fetch(`${API_BASE}/api/plans/saved`, {
            headers: { Authorization: `Bearer ${authToken}` },
        });
        if (response.status === 401) {
            handleAuthExpired();
            return;
        }
        const data = (await response.json());
        if (!response.ok || !data.plans) {
            setError(data.error?.message ?? "Could not load saved plans.");
            return;
        }
        setSavedPlans(data.plans);
    };
    const saveCurrentPlan = async () => {
        setError("");
        const activeSessionId = await ensureSession();
        if (!activeSessionId)
            return;
        if (!approvedForBuild) {
            setError("Approve this plan for build before saving it.");
            return;
        }
        try {
            const response = await fetch(`${API_BASE}/api/plans/${activeSessionId}/save`, {
                method: "POST",
                headers: withAuthHeaders(),
                body: JSON.stringify({
                    name: `${selectedTheme?.name ?? "Untitled"} - ${new Date().toLocaleString()}`,
                    approvedForBuild: true,
                }),
            });
            if (response.status === 401) {
                handleAuthExpired();
                return;
            }
            const data = (await response.json());
            if (!response.ok || !data.savedPlan) {
                setError(data.error?.message ?? "Failed to save plan.");
                return;
            }
            await refreshSavedPlans();
            setActivePanel("saved");
        }
        catch {
            setError("Could not save plan. Check backend and try again.");
        }
    };
    const loadSavedPlan = async (planId) => {
        setError("");
        try {
            const response = await fetch(`${API_BASE}/api/plans/saved/${planId}`, {
                headers: { Authorization: `Bearer ${authToken}` },
            });
            if (response.status === 401) {
                handleAuthExpired();
                return;
            }
            const data = (await response.json());
            if (!response.ok || !data.savedPlan) {
                setError(data.error?.message ?? "Failed to load saved plan.");
                return;
            }
            const payload = data.savedPlan.data;
            setSessionId(data.savedPlan.sessionId);
            setPlayersConcurrent(String(payload.planningInput.playersConcurrent));
            setParticipantsTotal(String(payload.planningInput.participantsTotal));
            setSessionDurationMinutes(String(payload.planningInput.sessionDurationMinutes));
            setEnvironmentType(payload.planningInput.environmentType);
            setAvailableItems(payload.planningInput.availableItems.join(", "));
            setExistingPuzzles(payload.planningInput.existingPuzzles);
            setThemes(payload.themes);
            setSelectedThemeId(payload.selectedThemeId);
            setPuzzles(payload.puzzles);
            setSuggestedAdditions(payload.suggestedAdditions);
            setStoryPlan(payload.storyPlan);
            setCompatibilityPassed(payload.compatibilityPassed);
            setExportContent(payload.exportContent ?? "");
            setApprovedForBuild(true);
            setShowPlanPicker(false);
            setActivePanel("output");
        }
        catch {
            setError("Could not load saved plan. Check backend and try again.");
        }
    };
    const deleteSavedPlan = async (planId) => {
        setError("");
        try {
            const response = await fetch(`${API_BASE}/api/plans/saved/${planId}`, {
                method: "DELETE",
                headers: { Authorization: `Bearer ${authToken}` },
            });
            if (response.status === 401) {
                handleAuthExpired();
                return;
            }
            const data = (await response.json());
            if (!response.ok || !data.deletedPlanId) {
                setError(data.error?.message ?? "Failed to delete saved plan.");
                return;
            }
            setSavedPlans((current) => current.filter((plan) => plan.planId !== planId));
        }
        catch {
            setError("Could not delete saved plan. Check backend and try again.");
        }
    };
    useEffect(() => {
        if (!authToken || !authUser) {
            setSavedPlans([]);
            return;
        }
        void refreshSavedPlans();
    }, [authToken, authUser]);
    if (!authUser) {
        return (_jsx("main", { className: "page-shell", children: _jsxs("div", { className: "auth-layout", children: [_jsx("section", { className: "hero auth-hero", children: _jsxs("div", { className: "hero-grid", children: [_jsxs("div", { children: [_jsx("p", { className: "hero-chip", children: "Immersive Planning Studio" }), _jsx("h1", { children: "Escape Room Builder" }), _jsx("p", { children: "Sign up or log in to design and save room plans." }), _jsxs("ul", { className: "auth-bullets", children: [_jsx("li", { children: "Generate cinematic room concepts quickly" }), _jsx("li", { children: "Save approved plans for future builds" }), _jsx("li", { children: "Export complete host-ready run sheets" })] })] }), _jsx("div", { className: "hero-visual", "aria-hidden": "true", children: _jsxs("svg", { viewBox: "0 0 220 140", role: "img", children: [_jsx("rect", { x: "10", y: "14", width: "200", height: "112", rx: "14" }), _jsx("circle", { cx: "70", cy: "70", r: "26" }), _jsx("circle", { cx: "70", cy: "70", r: "6" }), _jsx("path", { d: "M96 70h68M122 58l12 12-12 12" })] }) })] }) }), error ? _jsx("p", { className: "error-banner", children: error }) : null, _jsxs("section", { className: "card auth-card auth-panel", children: [_jsxs("div", { className: "auth-mode-row", children: [_jsx("button", { type: "button", className: authMode === "login" ? "primary-btn auth-mode-btn" : "auth-mode-btn", onClick: () => setAuthMode("login"), children: "Log In" }), _jsx("button", { type: "button", className: authMode === "signup" ? "primary-btn auth-mode-btn" : "auth-mode-btn", onClick: () => setAuthMode("signup"), children: "Sign Up" })] }), _jsxs("div", { className: "form-grid", children: [authMode === "signup" ? (_jsxs("label", { className: "field-row", children: ["Name", _jsx("input", { type: "text", value: authName, onChange: (event) => setAuthName(event.target.value) })] })) : null, _jsxs("label", { className: "field-row", children: ["Email", _jsx("input", { type: "email", value: authEmail, onChange: (event) => setAuthEmail(event.target.value) })] }), _jsxs("label", { className: "field-row", children: ["Password", _jsx("input", { type: "password", value: authPassword, onChange: (event) => setAuthPassword(event.target.value) })] }), _jsx("button", { type: "button", className: "primary-btn", onClick: authMode === "signup" ? handleSignup : handleLogin, children: authMode === "signup" ? "Create Account" : "Log In" })] }), _jsx("p", { className: "muted", children: "Or continue with social sign-in:" }), _jsxs("div", { className: "social-auth-grid", children: [_jsx("button", { type: "button", className: "social-btn social-google", onClick: () => handleSocialAuth("google"), children: "Continue with Google" }), _jsx("button", { type: "button", className: "social-btn social-facebook", onClick: () => handleSocialAuth("facebook"), children: "Continue with Facebook" }), _jsx("button", { type: "button", className: "social-btn social-github", onClick: () => handleSocialAuth("github"), children: "Continue with GitHub" })] })] })] }) }));
    }
    return (
    // Main application layout and interactive sections.
    _jsxs("main", { className: "page-shell", children: [_jsxs("section", { className: "hero", children: [_jsxs("div", { className: "hero-grid", children: [_jsxs("div", { children: [_jsx("p", { className: "hero-chip", children: "Mission Control" }), _jsx("h1", { children: "Escape Room Builder" }), _jsx("p", { children: "Design complete, theme-aligned rooms with story-driven progression." }), _jsxs("p", { className: "muted", children: ["Signed in as ", authUser.name, " (", authUser.email, ")"] })] }), _jsx("div", { className: "hero-visual", "aria-hidden": "true", children: _jsxs("svg", { viewBox: "0 0 220 140", role: "img", children: [_jsx("rect", { x: "10", y: "14", width: "200", height: "112", rx: "14" }), _jsx("circle", { cx: "70", cy: "70", r: "26" }), _jsx("circle", { cx: "70", cy: "70", r: "6" }), _jsx("path", { d: "M96 70h68M122 58l12 12-12 12" })] }) })] }), _jsx("div", { className: "button-row", children: _jsx("button", { type: "button", onClick: () => persistAuth("", null), children: "Log Out" }) })] }), _jsxs("section", { className: "card marketing-strip", children: [_jsx("h2", { children: "Build Rooms Like a Studio Team" }), _jsxs("div", { className: "features-grid", children: [_jsxs("article", { className: "feature-item", children: [_jsx("span", { className: "feature-icon", "aria-hidden": "true", children: "\uD83D\uDDFA\uFE0F" }), _jsx("h3", { children: "Flow-First Planning" }), _jsx("p", { children: "Move from concept to stage-based progression with clear reveal logic." })] }), _jsxs("article", { className: "feature-item", children: [_jsx("span", { className: "feature-icon", "aria-hidden": "true", children: "\uD83D\uDEE0\uFE0F" }), _jsx("h3", { children: "Build-Ready Details" }), _jsx("p", { children: "Use wiring, parts, references, and story rationale to prep production quickly." })] }), _jsxs("article", { className: "feature-item", children: [_jsx("span", { className: "feature-icon", "aria-hidden": "true", children: "\uD83D\uDCC5" }), _jsx("h3", { children: "Session-Aware Design" }), _jsx("p", { children: "Puzzle volume and complexity adjust to participant count and available minutes." })] })] })] }), _jsxs("section", { className: "card cta-strip", children: [_jsx("h2", { children: "Booking-Style Quick Actions" }), _jsxs("div", { className: "cta-grid", children: [_jsxs("article", { className: "cta-card", children: [_jsx("h3", { children: "Generate New Experience" }), _jsx("p", { children: "Jump into planning inputs and produce a full room concept from scratch." }), _jsx("button", { type: "button", className: "primary-btn", onClick: () => setActivePanel("plan"), children: "Start Planning" })] }), _jsxs("article", { className: "cta-card", children: [_jsx("h3", { children: "Resume Saved Build" }), _jsx("p", { children: "Open your approved plans and continue execution without repeating setup." }), _jsx("button", { type: "button", onClick: () => setActivePanel("saved"), children: "Open Saved Plans" })] })] })] }), _jsxs("div", { className: "workspace-layout", children: [_jsxs("aside", { className: "workspace-sidebar card", children: [_jsx("p", { className: "muted", children: "Workspace" }), _jsxs("nav", { className: "panel-nav", "aria-label": "Workspace sections", children: [_jsx("button", { type: "button", className: activePanel === "plan" ? "primary-btn" : "", onClick: () => setActivePanel("plan"), children: "Planning" }), _jsx("button", { type: "button", className: activePanel === "themes" ? "primary-btn" : "", onClick: () => setActivePanel("themes"), children: "Themes" }), _jsx("button", { type: "button", className: activePanel === "saved" ? "primary-btn" : "", onClick: () => setActivePanel("saved"), children: "Saved Plans" }), _jsx("button", { type: "button", className: activePanel === "output" ? "primary-btn" : "", onClick: () => setActivePanel("output"), children: "Puzzle Output" })] }), _jsx("p", { className: "muted", children: sessionId ? "Planning session active" : "Planning session not started" })] }), _jsxs("section", { className: "workspace-content", children: [error ? _jsx("p", { className: "error-banner", children: error }) : null, activePanel === "saved" && showPlanPicker ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Welcome Back" }), _jsx("p", { className: "muted", children: "Load a saved plan to continue where you left off, or start a new plan." }), savedPlans.length === 0 ? _jsx("p", { className: "muted", children: "No saved plans found for this account yet." }) : null, savedPlans.length > 0 ? (_jsx("ul", { className: "list-compact", children: savedPlans.map((plan) => (_jsxs("li", { children: [_jsx("strong", { children: plan.name }), " - ", plan.themeName, " (", plan.puzzleCount, " puzzles)", " ", _jsx("button", { type: "button", className: "secondary-btn", onClick: () => loadSavedPlan(plan.planId), children: "Load This Plan" })] }, `picker-${plan.planId}`))) })) : null, _jsx("div", { className: "button-row", children: _jsx("button", { type: "button", onClick: () => setShowPlanPicker(false), children: "Start New Plan" }) })] })) : null, activePanel === "plan" ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Planning Input" }), _jsxs("div", { className: "form-grid", children: [_jsxs("label", { children: ["Players at one time", _jsx("input", { type: "number", min: 1, value: playersConcurrent, onChange: (event) => setPlayersConcurrent(event.target.value) })] }), _jsxs("label", { children: ["Total participants", _jsx("input", { type: "number", min: 1, value: participantsTotal, onChange: (event) => setParticipantsTotal(event.target.value) })] }), _jsxs("label", { children: ["Session duration (minutes)", _jsx("input", { type: "number", min: 10, step: 5, value: sessionDurationMinutes, onChange: (event) => setSessionDurationMinutes(event.target.value) })] }), _jsxs("label", { children: ["Environment", _jsx("input", { type: "text", list: "environment-history", value: environmentType, onChange: (event) => setEnvironmentType(event.target.value), placeholder: "Physical room where game is played (e.g., living room, garage)" })] }), _jsx("datalist", { id: "environment-history", children: (inputHistory.environmentType ?? []).map((entry) => (_jsx("option", { value: entry }, entry))) }), _jsxs("label", { children: ["Available items (comma separated)", _jsx("input", { type: "text", list: "items-history", value: availableItems, onChange: (event) => setAvailableItems(event.target.value) })] }), _jsx("datalist", { id: "items-history", children: (inputHistory.availableItems ?? []).map((entry) => (_jsx("option", { value: entry }, entry))) }), _jsx("p", { className: "muted", children: "Environment means the real physical room and existing objects where players will play. Theme is separate." }), _jsxs("div", { className: "subcard", children: [_jsx("p", { className: "subcard-title", children: _jsx("strong", { children: "Existing puzzles to reuse" }) }), _jsxs("div", { className: "form-grid", children: [_jsxs("label", { className: "field-row", children: ["Puzzle name", _jsx("input", { type: "text", list: "existing-puzzle-name-history", value: existingPuzzleName, onChange: (event) => setExistingPuzzleName(event.target.value), placeholder: "Example: Telegraph Morse Box" })] }), _jsx("datalist", { id: "existing-puzzle-name-history", children: (inputHistory.existingPuzzleName ?? []).map((entry) => (_jsx("option", { value: entry }, entry))) }), _jsxs("label", { className: "field-row", children: ["Details link", _jsx("input", { type: "url", list: "existing-puzzle-link-history", value: existingPuzzleLink, onChange: (event) => setExistingPuzzleLink(event.target.value), placeholder: "https://..." })] }), _jsx("datalist", { id: "existing-puzzle-link-history", children: (inputHistory.existingPuzzleLink ?? []).map((entry) => (_jsx("option", { value: entry }, entry))) }), _jsxs("label", { className: "field-row", children: ["Room part / stage", _jsx("input", { type: "text", list: "existing-puzzle-roompart-history", value: existingPuzzleRoomPart, onChange: (event) => setExistingPuzzleRoomPart(event.target.value), placeholder: "Example: Intro, Mid-game, Finale" })] }), _jsx("datalist", { id: "existing-puzzle-roompart-history", children: (inputHistory.existingPuzzleRoomPart ?? []).map((entry) => (_jsx("option", { value: entry }, entry))) }), _jsx("button", { type: "button", className: "primary-btn", onClick: addExistingPuzzle, children: "Add Existing Puzzle" })] }), existingPuzzles.length > 0 ? (_jsx("ul", { className: "list-compact", children: existingPuzzles.map((puzzle, index) => (_jsxs("li", { children: [puzzle.name, " [", puzzle.roomPart, "] -", " ", _jsx("a", { href: puzzle.link, target: "_blank", rel: "noreferrer", children: puzzle.link }), " ", _jsx("button", { type: "button", onClick: () => removeExistingPuzzle(index), children: "Remove" })] }, `${puzzle.name}-${index}`))) })) : null] })] })] })) : null, activePanel === "plan" ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Use Your Own Theme" }), _jsxs("div", { className: "form-grid", children: [_jsxs("label", { children: ["Theme name", _jsx("input", { type: "text", list: "custom-theme-name-history", value: customThemeName, onChange: (event) => setCustomThemeName(event.target.value), placeholder: "Example: Ancient Temple Lockdown" })] }), _jsx("datalist", { id: "custom-theme-name-history", children: (inputHistory.customThemeName ?? []).map((entry) => (_jsx("option", { value: entry }, entry))) }), _jsxs("label", { children: ["Theme description (optional)", _jsx("input", { type: "text", list: "custom-theme-description-history", value: customThemeDescription, onChange: (event) => setCustomThemeDescription(event.target.value), placeholder: "Brief setup for puzzle generation context" })] }), _jsx("datalist", { id: "custom-theme-description-history", children: (inputHistory.customThemeDescription ?? []).map((entry) => (_jsx("option", { value: entry }, entry))) }), _jsx("button", { type: "button", className: "primary-btn", onClick: addCustomTheme, children: "Add and Select Custom Theme" })] })] })) : null, activePanel === "themes" ? (_jsxs("div", { className: "button-row", children: [_jsx("button", { type: "button", onClick: () => loadThemes("/api/themes/generate"), children: "Generate Themes" }), _jsx("button", { type: "button", onClick: () => loadThemes("/api/themes/refresh"), children: "Refresh Themes" }), _jsx("button", { type: "button", onClick: generatePuzzles, disabled: !selectedThemeId, children: "Generate Puzzles" }), _jsx("button", { type: "button", onClick: exportPlan, children: "Export Plan" }), _jsx("button", { type: "button", onClick: saveCurrentPlan, children: "Save Plan" }), _jsx("button", { type: "button", className: approvedForBuild ? "primary-btn" : "", onClick: () => setApprovedForBuild((current) => !current), children: approvedForBuild ? "Approved for Build" : "Mark Approved for Build" })] })) : null, activePanel === "saved" ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Saved Plans" }), savedPlans.length === 0 ? (_jsx("p", { className: "muted", children: "No saved plans yet for this account." })) : (_jsx("ul", { className: "list-compact", children: savedPlans.map((plan) => (_jsxs("li", { children: [_jsx("strong", { children: plan.name }), " - ", plan.themeName, " (", plan.puzzleCount, " puzzles)", " ", plan.approvedForBuild ? _jsx("span", { className: "status-pass", children: "Approved" }) : _jsx("span", { className: "muted", children: "Not approved" }), " ", _jsx("button", { type: "button", className: "secondary-btn", onClick: () => loadSavedPlan(plan.planId), children: "Load" }), _jsx("button", { type: "button", className: "secondary-btn", onClick: () => deleteSavedPlan(plan.planId), children: "Delete" })] }, plan.planId))) }))] })) : null, activePanel === "themes" ? (_jsx("ul", { className: "card list-compact", children: themes.map((theme) => (_jsx("li", { children: _jsxs("label", { children: [_jsx("input", { type: "radio", value: theme.id, checked: selectedThemeId === theme.id, onChange: () => {
                                                    void handleThemeSelect(theme.id);
                                                } }), _jsxs("strong", { children: [" ", theme.name] }), " - ", theme.description] }) }, theme.id))) })) : null, activePanel === "themes" && selectedTheme ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Selected Theme" }), _jsx("p", { children: selectedTheme.name })] })) : null, activePanel === "output" && suggestedAdditions.length > 0 ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Suggested Elements to Add (If Needed)" }), _jsx("ul", { className: "list-compact", children: suggestedAdditions.map((item) => (_jsx("li", { children: item }, item))) })] })) : null, activePanel === "output" && puzzles.length > 0 ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Puzzle Set" }), _jsxs("p", { className: compatibilityPassed ? "status-pass" : "status-fail", children: ["Theme compatibility checks passed: ", compatibilityPassed ? "Yes" : "No"] }), _jsx("ul", { className: "list-compact", children: puzzles.map((puzzle) => (_jsxs("li", { children: [_jsx("strong", { children: puzzle.title }), " (", puzzle.category, ", ", puzzle.difficulty, ") - ", puzzle.objective, _jsxs("p", { className: "inline-space", children: [_jsx("strong", { children: "How it works:" }), " ", puzzle.howItWorks] }), _jsxs("p", { className: "inline-space", children: [_jsx("strong", { children: "Why this fits the theme:" }), " ", puzzle.themeFitReason ??
                                                            deriveThemeFitFallback(selectedThemeName, selectedThemeDescription, puzzle)] }), _jsx("p", { className: "inline-space", children: _jsx("strong", { children: "References:" }) }), _jsx("ul", { className: "list-compact", children: (puzzle.referenceLinks ?? []).map((ref) => (_jsx("li", { children: _jsx("a", { href: ref.url, target: "_blank", rel: "noreferrer", children: ref.title }) }, ref.url))) }), _jsx("button", { type: "button", className: "secondary-btn", onClick: () => replacePuzzle(puzzle.id), children: "Replace" }), puzzle.category === "electronic" && puzzle.electronicDetails ? (_jsxs("div", { className: "subcard", children: [_jsx("p", { children: _jsx("strong", { children: "Parts" }) }), _jsx("ul", { className: "list-compact", children: puzzle.electronicDetails.parts.map((part) => (_jsx("li", { children: part }, part))) }), _jsx("p", { children: _jsx("strong", { children: "Wiring Diagram" }) }), _jsx("img", { src: `data:image/svg+xml;utf8,${encodeURIComponent(puzzle.electronicDetails.wiringDiagramSvg)}`, alt: `${puzzle.title} wiring diagram`, className: "diagram-img" }), _jsx("ul", { className: "list-compact", children: puzzle.electronicDetails.wiringDiagram.map((wire) => (_jsx("li", { children: wire }, wire))) }), _jsx("p", { children: _jsx("strong", { children: "Build Steps" }) }), _jsx("ol", { children: puzzle.electronicDetails.buildSteps.map((step) => (_jsx("li", { children: step }, step))) }), _jsx("p", { children: _jsx("strong", { children: "Arduino Code" }) }), _jsx("pre", { className: "code-block", children: puzzle.electronicDetails.arduinoCode })] })) : null] }, puzzle.id))) })] })) : null, activePanel === "output" && storyPlan ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Storyline and Progression" }), _jsxs("p", { children: [_jsx("strong", { children: "Situation:" }), " ", storyPlan.situation] }), _jsxs("p", { children: [_jsx("strong", { children: "Premise:" }), " ", storyPlan.premise] }), _jsxs("p", { children: [_jsx("strong", { children: "Mission objective:" }), " ", storyPlan.missionObjective] }), _jsxs("p", { children: [_jsx("strong", { children: "Progression rule:" }), " ", storyPlan.progressionRule] }), _jsx("h3", { children: "Stage Flow" }), _jsx("ul", { className: "list-compact", children: storyPlan.stages.map((stage) => (_jsxs("li", { children: [_jsx("strong", { children: stage.title }), " - ", stage.storyBeat, _jsx("br", {}), "Why: ", stage.whyThisStageExists, _jsx("br", {}), "Objective: ", stage.objective, _jsx("br", {}), "Required: ", stage.requiredPuzzleTitles.join(" and "), _jsx("br", {}), "Must do:", _jsx("ul", { className: "list-compact", children: stage.whatPlayersMustDo.map((step) => (_jsx("li", { children: step }, `${stage.stage}-${step}`))) }), "Reveals: ", stage.reveals] }, stage.stage))) }), _jsx("h3", { children: "Puzzle to Story Mapping" }), _jsx("ul", { className: "list-compact", children: storyPlan.puzzleLinks.map((link) => (_jsxs("li", { children: [_jsx("strong", { children: link.puzzleTitle }), " - ", link.storyRole, ". ", link.unlocks] }, link.puzzleId))) })] })) : null, activePanel === "output" && exportContent ? (_jsxs("section", { className: "card", children: [_jsx("h2", { children: "Export Output" }), _jsx("pre", { className: "code-block", children: exportContent })] })) : null] })] })] }));
}
