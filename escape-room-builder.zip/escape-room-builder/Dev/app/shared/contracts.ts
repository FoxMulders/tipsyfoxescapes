export type Difficulty = "easy" | "medium" | "hard";
export type PuzzleCategory = "logic" | "physical" | "electronic";

export interface PlanningInput {
  playersConcurrent: number;
  participantsTotal: number;
  environmentType: string;
  availableItems: string[];
}

export interface Theme {
  id: string;
  name: string;
  description: string;
}

export interface Puzzle {
  id: string;
  category: PuzzleCategory;
  title: string;
  objective: string;
  solveSteps: string[];
  difficulty: Difficulty;
}

export interface CreateSessionResponse {
  sessionId: string;
  createdAt: string;
}

export interface GenerateThemesResponse {
  themes: Theme[];
}

export interface GeneratePuzzlesResponse {
  puzzles: Puzzle[];
}

