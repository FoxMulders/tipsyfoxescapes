import express from "express";
import cors from "cors";
import { promises as fs } from "fs";
import path from "path";
import "dotenv/config";

type Theme = { id: string; name: string; description: string };
type Puzzle = {
  id: string;
  category: "logic" | "physical" | "electronic";
  themeTags: string[];
  title: string;
  objective: string;
  howItWorks: string;
  themeFitReason?: string;
  referenceLinks: { title: string; url: string }[];
  solveSteps: string[];
  difficulty: "easy" | "medium" | "hard";
  stageHint?: string;
  electronicDetails?: {
    parts: string[];
    wiringDiagram: string[];
    wiringDiagramSvg: string;
    buildSteps: string[];
    arduinoCode: string;
  };
};
type StoryStage = {
  stage: number;
  title: string;
  storyBeat: string;
  whyThisStageExists: string;
  objective: string;
  whatPlayersMustDo: string[];
  requiredPuzzleIds: string[];
  requiredPuzzleTitles: string[];
  reveals: string;
};
type StoryPuzzleLink = {
  puzzleId: string;
  puzzleTitle: string;
  storyRole: string;
  unlocks: string;
};
type StoryPlan = {
  situation: string;
  premise: string;
  missionObjective: string;
  progressionRule: string;
  stages: StoryStage[];
  puzzleLinks: StoryPuzzleLink[];
};
type SessionState = {
  planningInput: {
    playersConcurrent: number;
    participantsTotal: number;
    sessionDurationMinutes: number;
    environmentType: string;
    availableItems: string[];
    existingPuzzles: { name: string; link: string; roomPart: string }[];
  };
  customThemes: Theme[];
  generatedThemes: Theme[];
  selectedTheme?: Theme;
  generatedThemeCount: number;
  seenThemeIds: Set<string>;
  seenPuzzleIds: Set<string>;
  currentPuzzles: Puzzle[];
  suggestedAdditions: string[];
  currentStoryPlan?: StoryPlan;
};
type SkipEntryType = "theme" | "puzzle";
type SkipEntry = {
  type: SkipEntryType;
  id: string;
  skippedAtMs: number;
};
type AuthUser = {
  id: string;
  name: string;
  email: string;
  provider: "local" | "google" | "facebook" | "github";
  password?: string;
};
type SavedPlan = {
  planId: string;
  userId: string;
  sessionId: string;
  name: string;
  approvedForBuild: boolean;
  createdAt: string;
  updatedAt: string;
  data: {
    planningInput: SessionState["planningInput"];
    themes: Theme[];
    selectedThemeId: string;
    puzzles: Puzzle[];
    suggestedAdditions: string[];
    storyPlan: StoryPlan | null;
    compatibilityPassed: boolean;
    exportContent: string;
  };
};

const app = express();
// Allow frontend calls from the local dev server.
app.use(cors());
// Parse JSON request bodies for API endpoints.
app.use(express.json());
let nextSessionId = 1;
const sessions = new Map<string, SessionState>();
let nextThemeId = 1000;
const globallyServedThemeIds = new Set<string>();
let globalGeneratedThemeCount = 0;
const globallyServedThemeNames = new Set<string>();
const SKIP_TTL_MS = 24 * 60 * 60 * 1000;
const skipHistoryPath = path.join(process.cwd(), "data", "skip-history.json");
const skipEntries = new Map<string, SkipEntry>();
const usersByEmail = new Map<string, AuthUser>();
const authTokens = new Map<string, string>();
let nextUserId = 1;
const savedPlansPath = path.join(process.cwd(), "data", "user-plans.json");
const savedPlansByUser = new Map<string, SavedPlan[]>();
const oauthStateStore = new Map<
  string,
  { provider: "google" | "facebook" | "github"; returnTo: string; createdAtMs: number }
>();
const OAUTH_STATE_TTL_MS = 10 * 60 * 1000;

const themePool: Theme[] = [
  { id: "th_1", name: "Haunted Library", description: "Books and hidden ciphers." },
  { id: "th_2", name: "Railway Heist", description: "Secure the stolen ledger." },
  { id: "th_3", name: "Submerged Lab", description: "Restore power and escape." },
  { id: "th_4", name: "Clockmaker Vault", description: "Solve mechanism timing." },
  { id: "th_5", name: "Arcade Blackout", description: "Reactivate old cabinets." },
  { id: "th_6", name: "Signal Outpost", description: "Transmit the rescue code." },
];
const generatedThemeAdjectives = [
  "Forsaken",
  "Neon",
  "Clockwork",
  "Frozen",
  "Sunken",
  "Crimson",
  "Hidden",
  "Astral",
  "Arcane",
  "Shattered",
];
const generatedThemeNouns = [
  "Observatory",
  "Vault",
  "Catacombs",
  "Laboratory",
  "Outpost",
  "Sanctuary",
  "Citadel",
  "Archives",
  "Theater",
  "Foundry",
];
const generatedThemeTwists = [
  "where power cycles every 90 seconds",
  "with clues split between light and shadow",
  "that resets after each wrong code",
  "with hidden signals in ambient audio",
  "where team roles unlock different paths",
  "that reveals clues only in sequence",
  "with decoy mechanisms and one true route",
  "where each solved puzzle changes the room state",
  "that requires synchronized player actions",
  "with rotating clue stations",
];

const getThemeContext = (theme?: Theme): { requiredTag?: string; bannedTags: string[] } => {
  // Infer compatibility constraints from the selected theme text.
  const text = `${theme?.name ?? ""} ${theme?.description ?? ""}`.toLowerCase();
  if (
    text.includes("old west") ||
    text.includes("western") ||
    text.includes("cowboy") ||
    text.includes("saloon")
  ) {
    return {
      requiredTag: "old-west",
      bannedTags: ["modern-timepiece", "modern-electronics"],
    };
  }
  return { bannedTags: [] };
};

const isPuzzleCompatibleWithTheme = (puzzle: Puzzle, theme?: Theme): boolean => {
  const context = getThemeContext(theme);
  if (context.bannedTags.some((tag) => puzzle.themeTags.includes(tag))) return false;
  if (!context.requiredTag) return true;
  return puzzle.themeTags.includes(context.requiredTag) || puzzle.themeTags.includes("generic");
};

const deriveThemeFitReason = (puzzle: Puzzle, theme?: Theme): string => {
  const themeName = theme?.name ?? "this theme";
  const text = `${theme?.name ?? ""} ${theme?.description ?? ""}`.toLowerCase();
  const isSciFi =
    text.includes("guardians") ||
    text.includes("galaxy") ||
    text.includes("space") ||
    text.includes("futur") ||
    text.includes("ship") ||
    text.includes("prison");
  const isPrisonBreak = text.includes("prison") || text.includes("lockdown") || text.includes("cell");
  const isOldWest =
    text.includes("old west") || text.includes("western") || text.includes("cowboy") || text.includes("saloon");

  const usesElectronics = puzzle.themeTags.includes("modern-electronics");
  const usesMechanical = puzzle.themeTags.includes("mechanical");
  const usesDeduction = puzzle.themeTags.includes("mystery") || puzzle.themeTags.includes("deduction");
  const title = puzzle.title.toLowerCase();
  const hasLedOrSignal =
    title.includes("signal") ||
    title.includes("pulse") ||
    title.includes("relay") ||
    puzzle.objective.toLowerCase().includes("light");

  if (isOldWest) {
    if (puzzle.themeTags.includes("old-west")) {
      return `For "${themeName}", this puzzle uses period-appropriate interaction and props, so it feels native to an Old West setting rather than modern tech.`;
    }
    return `For "${themeName}", this puzzle still fits because it avoids immersion-breaking modern elements while advancing the same frontier-style clue progression.`;
  }

  if (isSciFi && isPrisonBreak && usesElectronics && hasLedOrSignal) {
    return `For "${themeName}", this puzzle reads like a futuristic prison control system: LED/signal feedback resembles security circuitry, making the challenge feel like sabotaging or rerouting cell-block tech.`;
  }

  if (isSciFi && usesElectronics) {
    return `For "${themeName}", this puzzle fits because electronic feedback and signal logic match a high-tech sci-fi environment and make the room feel like functioning advanced infrastructure.`;
  }

  if (isPrisonBreak && usesMechanical) {
    return `For "${themeName}", this puzzle fits the prison-break tone by focusing on controlled physical mechanisms, similar to bypassing locks or manipulating constrained escape hardware.`;
  }

  if (usesMechanical) {
    return `For "${themeName}", this puzzle fits by providing tactile mechanical interaction that grounds the scenario in believable in-world machinery and props.`;
  }
  if (usesDeduction) {
    return `For "${themeName}", this puzzle fits by turning narrative clues into deduction, reinforcing the story logic instead of feeling like an isolated mini-game.`;
  }
  if (usesElectronics) {
    return `For "${themeName}", this puzzle fits because its interactive electronic behavior supports the room's technical systems feel and staged reveals.`;
  }
  return `For "${themeName}", this puzzle supports the theme through story-consistent clue style, pacing, and progression role.`;
};

const withThemeFitReasons = (puzzles: Puzzle[], theme?: Theme): Puzzle[] =>
  puzzles.map((puzzle) => ({
    ...puzzle,
    themeFitReason: deriveThemeFitReason(puzzle, theme),
  }));

const withSingleReferenceLink = (puzzles: Puzzle[]): Puzzle[] =>
  puzzles.map((puzzle) => ({
    ...puzzle,
    referenceLinks: puzzle.referenceLinks.length > 0 ? [puzzle.referenceLinks[0]] : [],
  }));

const getSuggestedAdditions = (session: SessionState, puzzles: Puzzle[]): string[] => {
  const additions: string[] = [];
  const room = session.planningInput.environmentType.toLowerCase();
  const items = session.planningInput.availableItems.map((item) => item.toLowerCase());
  const hasItem = (needle: string) => items.some((item) => item.includes(needle));
  const electronicCount = puzzles.filter((puzzle) => puzzle.category === "electronic").length;

  additions.push(
    "Label the room boundary and puzzle zones so players understand where gameplay objects are intentionally placed.",
  );

  if (!hasItem("lock")) {
    additions.push("Add at least 2 lockable containers (hasp box, lock box, or drawer latch) for staged reveals.");
  }
  if (!hasItem("board") && !hasItem("whiteboard")) {
    additions.push("Add a clue board or pin area for team clue tracking and deduction mapping.");
  }
  if (electronicCount > 0 && !hasItem("arduino")) {
    additions.push(
      "Add an electronics kit station (Arduino, breadboard, jumper wires, resistors) to support electronic puzzles.",
    );
  }
  if (room.includes("living room") || room.includes("house")) {
    additions.push("Add temporary cable covers/tape routes to keep wiring safe in shared household spaces.");
    additions.push("Add removable prop mounts (command hooks/strips) to avoid permanent room modifications.");
  }
  if (room.includes("garage") || room.includes("basement")) {
    additions.push("Add focused lighting for clue visibility and a clear safe path around stored equipment.");
  }

  return additions;
};

const estimatePuzzleCount = (playersConcurrent: number, sessionDurationMinutes: number): number => {
  // Time-first guardrails:
  // Very short sessions must have very few puzzles, otherwise rooms become unsolvable.
  if (sessionDurationMinutes <= 5) return 1;
  if (sessionDurationMinutes <= 10) return Math.min(2, Math.max(1, Math.ceil(playersConcurrent / 3)));
  if (sessionDurationMinutes <= 15) return Math.min(3, Math.max(2, Math.ceil(playersConcurrent / 2)));
  if (sessionDurationMinutes <= 30) return Math.min(6, Math.max(3, Math.ceil((playersConcurrent * sessionDurationMinutes) / 40)));

  // Standard sessions (30+ min): scale by players and runtime.
  const raw = Math.ceil((playersConcurrent * sessionDurationMinutes) / 30);
  return Math.max(4, Math.min(18, raw));
};

const chunkByTwo = <T>(items: T[]): T[][] => {
  const chunks: T[][] = [];
  for (let i = 0; i < items.length; i += 2) {
    chunks.push(items.slice(i, i + 2));
  }
  return chunks;
};

const createStoryPlan = (theme: Theme | undefined, puzzles: Puzzle[]): StoryPlan => {
  // Stage hints control where user-provided puzzles appear in progression.
  const themeName = theme?.name ?? "Unknown Theme";
  const themeDescription = theme?.description ?? "No description provided.";
  const missionObjective = themeDescription;
  const getStageWeight = (puzzle: Puzzle): number => {
    const hint = (puzzle.stageHint ?? "").toLowerCase();
    if (!hint) return 2;
    if (
      hint.includes("final") ||
      hint.includes("exit") ||
      hint.includes("end") ||
      hint.includes("opens final door") ||
      hint.includes("boss")
    ) {
      return 3;
    }
    if (
      hint.includes("intro") ||
      hint.includes("start") ||
      hint.includes("begin") ||
      hint.includes("opening")
    ) {
      return 1;
    }
    if (hint.includes("mid") || hint.includes("middle")) {
      return 2;
    }
    return 2;
  };

  const orderedPuzzles = [...puzzles].sort((a, b) => getStageWeight(a) - getStageWeight(b));
  const groups = chunkByTwo(orderedPuzzles);
  const stageBeatTemplates = [
    "Initial discovery and orientation",
    "Information synthesis under pressure",
    "System activation and control",
    "Final containment and escape",
  ];
  const stages: StoryStage[] = groups.map((group, index) => {
    const nextGroup = groups[index + 1] ?? [];
    const reveals =
      nextGroup.length > 0
        ? `Completing both required puzzles reveals ${nextGroup.map((p) => `"${p.title}"`).join(" and ")}, advancing the mission: ${missionObjective}.`
        : `Completing both required puzzles unlocks the final sequence needed to complete the mission: ${missionObjective}.`;
    const stageLabel = stageBeatTemplates[index] ?? "Escalation and resolution";
    return {
      stage: index + 1,
      title: `Stage ${index + 1}`,
      storyBeat: stageLabel,
      whyThisStageExists:
        nextGroup.length > 0
          ? "This stage is designed to split players into parallel problem-solving tracks so no one is idle."
          : "This stage converges all prior clues into the final unlock condition and ending sequence.",
      objective:
        nextGroup.length > 0
          ? `Solve both parallel elements to progress toward: ${missionObjective}.`
          : `Solve both final elements to complete: ${missionObjective}.`,
      whatPlayersMustDo: [
        `Complete "${group[0]?.title ?? "Puzzle A"}" and "${group[1]?.title ?? "Puzzle B"}".`,
        "Cross-check outputs from both puzzles to confirm the reveal condition.",
        nextGroup.length > 0
          ? `Trigger next-stage reveal mechanism that moves the team closer to: ${missionObjective}.`
          : `Trigger final door release condition and resolve: ${missionObjective}.`,
      ],
      requiredPuzzleIds: group.map((puzzle) => puzzle.id),
      requiredPuzzleTitles: group.map((puzzle) => puzzle.title),
      reveals,
    };
  });

  const puzzleLinks: StoryPuzzleLink[] = groups.flatMap((group, index) => {
    const nextGroup = groups[index + 1] ?? [];
    return group.map((puzzle) => ({
      puzzleId: puzzle.id,
      puzzleTitle: puzzle.title,
      storyRole:
        index === 0
          ? "Opening discovery puzzle"
          : index === groups.length - 1
            ? "Final lock path puzzle"
            : "Mid-game escalation puzzle",
      unlocks:
        nextGroup.length > 0
          ? `Acts as one of two required solves to reveal ${nextGroup.map((p) => `"${p.title}"`).join(" and ")}, supporting the mission: ${missionObjective}.`
          : `Acts as one of two required solves that reveals the final exit mechanism to complete: ${missionObjective}.`,
    }));
  });

  return {
    situation: `Players are trapped inside a ${themeName} scenario and must decode layered clues before the environment reaches failure state.`,
    premise: `${themeName}: ${themeDescription}`,
    missionObjective,
    progressionRule:
      "At least two puzzle elements must be solved in each stage before the next stage is revealed, keeping players engaged in parallel.",
    stages,
    puzzleLinks,
  };
};

const shuffle = <T>(items: T[]): T[] => {
  // Fisher-Yates shuffle.
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = copy[i];
    copy[i] = copy[j];
    copy[j] = temp;
  }
  return copy;
};

const createGeneratedTheme = (prefix: string): Theme => {
  globalGeneratedThemeCount += 1;
  const idx = globalGeneratedThemeCount;
  const adjective = generatedThemeAdjectives[Math.floor(Math.random() * generatedThemeAdjectives.length)];
  const noun = generatedThemeNouns[Math.floor(Math.random() * generatedThemeNouns.length)];
  const twist = generatedThemeTwists[Math.floor(Math.random() * generatedThemeTwists.length)];
  return {
    id: `${prefix}_${idx}`,
    name: `${adjective} ${noun}`,
    description: `A unique session concept ${twist}.`,
  };
};

const skipKey = (type: SkipEntryType, id: string): string => `${type}:${id}`;

const pruneExpiredSkips = (): void => {
  const now = Date.now();
  for (const [key, entry] of skipEntries.entries()) {
    if (now - entry.skippedAtMs >= SKIP_TTL_MS) {
      skipEntries.delete(key);
    }
  }
};

const isSkipped = (type: SkipEntryType, id: string): boolean => {
  pruneExpiredSkips();
  const entry = skipEntries.get(skipKey(type, id));
  if (!entry) return false;
  return Date.now() - entry.skippedAtMs < SKIP_TTL_MS;
};

const markSkipped = (type: SkipEntryType, id: string): void => {
  skipEntries.set(skipKey(type, id), { type, id, skippedAtMs: Date.now() });
};

const persistSkipHistory = async (): Promise<void> => {
  pruneExpiredSkips();
  try {
    await fs.mkdir(path.dirname(skipHistoryPath), { recursive: true });
    const payload = JSON.stringify({ entries: Array.from(skipEntries.values()) }, null, 2);
    await fs.writeFile(skipHistoryPath, payload, "utf8");
  } catch {
    // Best-effort persistence only.
  }
};

const loadSkipHistory = async (): Promise<void> => {
  try {
    const raw = await fs.readFile(skipHistoryPath, "utf8");
    const parsed = JSON.parse(raw) as { entries?: SkipEntry[] };
    if (!Array.isArray(parsed.entries)) return;
    for (const entry of parsed.entries) {
      if (!entry?.id || !entry?.type || !entry?.skippedAtMs) continue;
      skipEntries.set(skipKey(entry.type, entry.id), entry);
    }
    pruneExpiredSkips();
  } catch {
    // No saved history yet.
  }
};

const puzzlePoolByCategory: Record<Puzzle["category"], Puzzle[]> = {
  logic: [
    {
      id: "pz_logic_1",
      category: "logic",
      themeTags: ["generic", "mystery"],
      title: "Cipher Index",
      objective: "Decode the message.",
      howItWorks:
        "Players discover an encoded clue and a key hint in separate locations. They must identify the cipher pattern, apply the key, and decode the final phrase that reveals the next lock combination.",
      referenceLinks: [
        { title: "Puzzle Pieces channel", url: "https://www.youtube.com/@PuzzlePieces" },
        {
          title: "Playful Technology channel",
          url: "https://www.youtube.com/@playfultechnology",
        },
        {
          title: "Cipher puzzle examples (YouTube)",
          url: "https://www.youtube.com/results?search_query=escape+room+cipher+puzzle",
        },
      ],
      solveSteps: ["Find key", "Apply shift"],
      difficulty: "medium",
    },
    {
      id: "pz_logic_2",
      category: "logic",
      themeTags: ["generic", "symbolic"],
      title: "Pattern Archive",
      objective: "Match symbol sequence to unlock clue.",
      howItWorks:
        "Players gather symbols from props around the room. They compare symbol order to a reference board and reconstruct the correct sequence, which opens a hidden compartment.",
      referenceLinks: [
        { title: "Puzzle Pieces channel", url: "https://www.youtube.com/@PuzzlePieces" },
        {
          title: "Symbol puzzle inspiration (YouTube)",
          url: "https://www.youtube.com/results?search_query=escape+room+symbol+puzzle+design",
        },
        {
          title: "Room Escape Artist puzzle ideas",
          url: "https://roomescapeartist.com/",
        },
      ],
      solveSteps: ["Collect symbols", "Align sequence"],
      difficulty: "medium",
    },
    {
      id: "pz_logic_3",
      category: "logic",
      themeTags: ["generic", "deduction"],
      title: "Riddle Ledger",
      objective: "Solve chained riddles to extract a 4-digit code.",
      howItWorks:
        "Players solve a sequence of short clues where each answer points to the next riddle card. The final answers map to numbers that open the next lock.",
      referenceLinks: [
        { title: "Puzzle Pieces channel", url: "https://www.youtube.com/@PuzzlePieces" },
        {
          title: "Escape room riddle chains (YouTube)",
          url: "https://www.youtube.com/results?search_query=escape+room+riddle+chain+puzzle",
        },
      ],
      solveSteps: ["Read first riddle", "Follow answer chain", "Convert final answers to code"],
      difficulty: "medium",
    },
    {
      id: "pz_logic_4",
      category: "logic",
      themeTags: ["generic", "mapping"],
      title: "Coordinate Cipher Grid",
      objective: "Use coordinates to decode a hidden instruction.",
      howItWorks:
        "Players combine coordinate clues from multiple props and index into a letter grid, revealing a phrase that unlocks the next puzzle stage.",
      referenceLinks: [
        {
          title: "Grid cipher puzzle ideas (YouTube)",
          url: "https://www.youtube.com/results?search_query=grid+cipher+escape+room+puzzle",
        },
        { title: "Puzzle Pieces channel", url: "https://www.youtube.com/@PuzzlePieces" },
      ],
      solveSteps: ["Collect coordinate clues", "Map clues onto grid", "Decode resulting phrase"],
      difficulty: "medium",
    },
  ],
  physical: [
    {
      id: "pz_physical_1",
      category: "physical",
      themeTags: ["generic", "mechanical"],
      title: "Weighted Switch",
      objective: "Balance objects to unlock compartment.",
      howItWorks:
        "A pressure plate or balance mechanism only triggers when object mass is distributed correctly. Players test combinations until the mechanism reaches equilibrium and releases a latch.",
      referenceLinks: [
        { title: "Puzzle Pieces channel", url: "https://www.youtube.com/@PuzzlePieces" },
        {
          title: "Balance puzzle build examples (YouTube)",
          url: "https://www.youtube.com/results?search_query=escape+room+balance+puzzle+build",
        },
        {
          title: "Wickes/DIY mechanical puzzle ideas (YouTube)",
          url: "https://www.youtube.com/results?search_query=DIY+mechanical+escape+room+puzzle",
        },
      ],
      solveSteps: ["Collect weights", "Balance tray"],
      difficulty: "medium",
    },
    {
      id: "pz_physical_2",
      category: "physical",
      themeTags: ["generic", "magnet"],
      title: "Magnetic Lock Sequence",
      objective: "Align magnetic triggers in order.",
      howItWorks:
        "Magnetic sensors are hidden behind marked points. Players move a magnet in the correct order and timing to activate all sensors and unlock the next clue container.",
      referenceLinks: [
        {
          title: "Playful Technology channel",
          url: "https://www.youtube.com/@playfultechnology",
        },
        {
          title: "Magnetic sensor puzzle builds (YouTube)",
          url: "https://www.youtube.com/results?search_query=reed+switch+escape+room+puzzle",
        },
        {
          title: "Adafruit reed switch guide",
          url: "https://learn.adafruit.com/search?q=reed%20switch",
        },
      ],
      solveSteps: ["Find magnet points", "Activate sequence"],
      difficulty: "medium",
    },
    {
      id: "pz_physical_3",
      category: "physical",
      themeTags: ["generic", "assembly"],
      title: "Artifact Assembly",
      objective: "Assemble parts in the correct orientation to reveal a clue.",
      howItWorks:
        "Players gather separated parts of an object and physically align them. A hidden pattern or message only appears when assembled correctly.",
      referenceLinks: [
        {
          title: "Physical assembly puzzle ideas (YouTube)",
          url: "https://www.youtube.com/results?search_query=physical+assembly+escape+room+puzzle",
        },
        { title: "Puzzle Pieces channel", url: "https://www.youtube.com/@PuzzlePieces" },
      ],
      solveSteps: ["Find all parts", "Align in correct order", "Read revealed clue"],
      difficulty: "medium",
    },
    {
      id: "pz_physical_4",
      category: "physical",
      themeTags: ["generic", "navigation"],
      title: "Pathfinder Track",
      objective: "Route a token through the correct track sequence.",
      howItWorks:
        "Players must interpret route markers and physically move a token along a constrained path. A wrong route dead-ends and forces a retry.",
      referenceLinks: [
        {
          title: "Track/maze puzzle builds (YouTube)",
          url: "https://www.youtube.com/results?search_query=escape+room+maze+track+puzzle",
        },
      ],
      solveSteps: ["Interpret route hints", "Navigate token path", "Trigger endpoint switch"],
      difficulty: "medium",
    },
  ],
  electronic: [
    {
      id: "pz_electronic_1",
      category: "electronic",
      themeTags: ["generic", "modern-electronics"],
      title: "Signal Relay",
      objective: "Complete the circuit to light the clue.",
      howItWorks:
        "Players complete a button-and-LED circuit driven by an Arduino. When they press the button sequence correctly, the sketch toggles LEDs and reveals the success signal.",
      referenceLinks: [
        {
          title: "Playful Technology channel",
          url: "https://www.youtube.com/@playfultechnology",
        },
        {
          title: "Puzzle Pieces channel",
          url: "https://www.youtube.com/@PuzzlePieces",
        },
        {
          title: "Arduino button and LED puzzle examples (YouTube)",
          url: "https://www.youtube.com/results?search_query=arduino+escape+room+button+led+puzzle",
        },
      ],
      solveSteps: ["Wire LEDs", "Upload sketch"],
      difficulty: "medium",
      electronicDetails: {
        parts: [
          "Arduino Uno (or compatible)",
          "Breadboard",
          "2x LEDs (red/green)",
          "2x 220 ohm resistors",
          "1x push button",
          "1x 10k ohm resistor",
          "Jumper wires",
          "USB cable",
        ],
        wiringDiagram: [
          "D8 -> 220 ohm resistor -> Red LED anode, LED cathode -> GND",
          "D9 -> 220 ohm resistor -> Green LED anode, LED cathode -> GND",
          "Button leg 1 -> 5V",
          "Button leg 2 -> D2 and 10k ohm resistor to GND (pulldown)",
          "Arduino GND -> breadboard ground rail",
        ],
        wiringDiagramSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="980" height="420" viewBox="0 0 980 420">
  <rect x="20" y="20" width="220" height="360" fill="#f4f6f8" stroke="#333"/>
  <text x="130" y="48" text-anchor="middle" font-family="Arial" font-size="18">Arduino Uno</text>
  <text x="36" y="96" font-family="Arial" font-size="14">D8</text>
  <text x="36" y="126" font-family="Arial" font-size="14">D9</text>
  <text x="36" y="156" font-family="Arial" font-size="14">D2</text>
  <text x="36" y="186" font-family="Arial" font-size="14">5V</text>
  <text x="36" y="216" font-family="Arial" font-size="14">GND</text>
  <circle cx="92" cy="92" r="3" fill="#111"/><circle cx="92" cy="122" r="3" fill="#111"/><circle cx="92" cy="152" r="3" fill="#111"/><circle cx="92" cy="182" r="3" fill="#111"/><circle cx="92" cy="212" r="3" fill="#111"/>

  <rect x="280" y="20" width="680" height="360" fill="#fff" stroke="#333"/>
  <text x="620" y="48" text-anchor="middle" font-family="Arial" font-size="18">Breadboard (with rails and holes)</text>
  <line x1="310" y1="78" x2="930" y2="78" stroke="#d32f2f" stroke-width="3"/>
  <line x1="310" y1="94" x2="930" y2="94" stroke="#1976d2" stroke-width="3"/>
  <line x1="310" y1="320" x2="930" y2="320" stroke="#d32f2f" stroke-width="3"/>
  <line x1="310" y1="336" x2="930" y2="336" stroke="#1976d2" stroke-width="3"/>
  <text x="934" y="82" font-family="Arial" font-size="11">+ rail</text>
  <text x="934" y="98" font-family="Arial" font-size="11">- rail</text>
  <text x="934" y="324" font-family="Arial" font-size="11">+ rail</text>
  <text x="934" y="340" font-family="Arial" font-size="11">- rail</text>

  <g fill="#bbb">
    <circle cx="340" cy="140" r="2"/><circle cx="360" cy="140" r="2"/><circle cx="380" cy="140" r="2"/><circle cx="400" cy="140" r="2"/><circle cx="420" cy="140" r="2"/>
    <circle cx="340" cy="160" r="2"/><circle cx="360" cy="160" r="2"/><circle cx="380" cy="160" r="2"/><circle cx="400" cy="160" r="2"/><circle cx="420" cy="160" r="2"/>
    <circle cx="340" cy="180" r="2"/><circle cx="360" cy="180" r="2"/><circle cx="380" cy="180" r="2"/><circle cx="400" cy="180" r="2"/><circle cx="420" cy="180" r="2"/>
    <circle cx="520" cy="140" r="2"/><circle cx="540" cy="140" r="2"/><circle cx="560" cy="140" r="2"/><circle cx="580" cy="140" r="2"/><circle cx="600" cy="140" r="2"/>
    <circle cx="520" cy="160" r="2"/><circle cx="540" cy="160" r="2"/><circle cx="560" cy="160" r="2"/><circle cx="580" cy="160" r="2"/><circle cx="600" cy="160" r="2"/>
    <circle cx="520" cy="180" r="2"/><circle cx="540" cy="180" r="2"/><circle cx="560" cy="180" r="2"/><circle cx="580" cy="180" r="2"/><circle cx="600" cy="180" r="2"/>
  </g>

  <circle cx="710" cy="150" r="10" fill="#d32f2f"/><text x="726" y="154" font-family="Arial" font-size="12">Red LED</text>
  <circle cx="710" cy="186" r="10" fill="#2e7d32"/><text x="728" y="190" font-family="Arial" font-size="12">Green LED</text>
  <rect x="650" y="230" width="120" height="24" fill="#ddd" stroke="#333"/><text x="778" y="246" font-family="Arial" font-size="12">Push Button</text>

  <polyline points="610,150 624,144 638,156 652,144 666,156 680,150" fill="none" stroke="#8d6e63" stroke-width="2"/>
  <text x="686" y="154" font-family="Arial" font-size="11">220R</text>
  <polyline points="610,186 624,180 638,192 652,180 666,192 680,186" fill="none" stroke="#8d6e63" stroke-width="2"/>
  <text x="686" y="190" font-family="Arial" font-size="11">220R</text>
  <polyline points="610,254 624,248 638,260 652,248 666,260 680,254" fill="none" stroke="#8d6e63" stroke-width="2"/>
  <text x="686" y="258" font-family="Arial" font-size="11">10k</text>

  <line x1="92" y1="92" x2="610" y2="150" stroke="#1976d2" stroke-width="2.5"/><text x="250" y="104" font-family="Arial" font-size="11">D8</text>
  <line x1="680" y1="150" x2="700" y2="150" stroke="#1976d2" stroke-width="2.5"/>
  <line x1="92" y1="122" x2="610" y2="186" stroke="#1976d2" stroke-width="2.5"/><text x="250" y="132" font-family="Arial" font-size="11">D9</text>
  <line x1="680" y1="186" x2="700" y2="186" stroke="#1976d2" stroke-width="2.5"/>

  <line x1="92" y1="182" x2="650" y2="242" stroke="#e53935" stroke-width="2.5"/><text x="250" y="176" font-family="Arial" font-size="11">5V to button leg 1</text>
  <line x1="92" y1="152" x2="650" y2="242" stroke="#fb8c00" stroke-width="2.5"/><text x="250" y="154" font-family="Arial" font-size="11">D2 to button leg 2</text>
  <line x1="770" y1="242" x2="610" y2="254" stroke="#fb8c00" stroke-width="2.5"/>
  <line x1="680" y1="254" x2="680" y2="336" stroke="#424242" stroke-width="2.5"/>

  <line x1="92" y1="212" x2="710" y2="160" stroke="#424242" stroke-width="2.5"/>
  <line x1="92" y1="212" x2="710" y2="196" stroke="#424242" stroke-width="2.5"/>
  <line x1="92" y1="212" x2="930" y2="336" stroke="#424242" stroke-width="2"/>
  <text x="300" y="364" font-family="Arial" font-size="12">Gray lines = GND return paths</text>
</svg>`,
        buildSteps: [
          "Assemble circuit exactly as listed in wiring diagram.",
          "Open Arduino IDE, select board and COM port.",
          "Upload the provided sketch.",
          "Press the button in the right sequence to trigger green LED and reveal clue.",
        ],
        arduinoCode: `const int redLed = 8;
const int greenLed = 9;
const int buttonPin = 2;
int presses = 0;
unsigned long lastPress = 0;

void setup() {
  pinMode(redLed, OUTPUT);
  pinMode(greenLed, OUTPUT);
  pinMode(buttonPin, INPUT);
  digitalWrite(redLed, HIGH);
}

void loop() {
  int state = digitalRead(buttonPin);
  if (state == HIGH && millis() - lastPress > 300) {
    lastPress = millis();
    presses++;
  }

  if (presses >= 3) {
    digitalWrite(redLed, LOW);
    digitalWrite(greenLed, HIGH);
  }
}`,
      },
    },
    {
      id: "pz_electronic_2",
      category: "electronic",
      themeTags: ["generic", "modern-electronics"],
      title: "Code Pulse",
      objective: "Send pulse pattern to reveal code.",
      howItWorks:
        "The Arduino emits timed buzzer and LED pulses representing a code pattern. Players observe short and long pulses, decode them, and convert the pattern into the answer.",
      referenceLinks: [
        {
          title: "Playful Technology channel",
          url: "https://www.youtube.com/@playfultechnology",
        },
        {
          title: "Buzzer code puzzle examples (YouTube)",
          url: "https://www.youtube.com/results?search_query=arduino+buzzer+code+escape+room",
        },
        {
          title: "Arduino tone() reference",
          url: "https://www.arduino.cc/reference/en/language/functions/advanced-io/tone/",
        },
      ],
      solveSteps: ["Connect buzzer", "Upload pulse routine"],
      difficulty: "medium",
      electronicDetails: {
        parts: [
          "Arduino Uno (or compatible)",
          "Passive buzzer",
          "1x LED",
          "1x 220 ohm resistor",
          "Breadboard",
          "Jumper wires",
          "USB cable",
        ],
        wiringDiagram: [
          "D6 -> buzzer positive",
          "Buzzer negative -> GND",
          "D10 -> 220 ohm resistor -> LED anode",
          "LED cathode -> GND",
          "Arduino GND -> breadboard ground rail",
        ],
        wiringDiagramSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="340" viewBox="0 0 900 340">
  <rect x="20" y="20" width="220" height="280" fill="#f4f6f8" stroke="#333" />
  <text x="130" y="50" text-anchor="middle" font-family="Arial" font-size="18">Arduino Uno</text>
  <text x="40" y="95" font-family="Arial" font-size="14">D6</text>
  <text x="40" y="125" font-family="Arial" font-size="14">D10</text>
  <text x="40" y="155" font-family="Arial" font-size="14">GND</text>
  <rect x="300" y="20" width="560" height="280" fill="#fff" stroke="#333" />
  <text x="580" y="50" text-anchor="middle" font-family="Arial" font-size="18">Breadboard (hole grid)</text>
  <g fill="#bbb">
    <circle cx="350" cy="110" r="2"/><circle cx="370" cy="110" r="2"/><circle cx="390" cy="110" r="2"/><circle cx="410" cy="110" r="2"/><circle cx="430" cy="110" r="2"/>
    <circle cx="350" cy="130" r="2"/><circle cx="370" cy="130" r="2"/><circle cx="390" cy="130" r="2"/><circle cx="410" cy="130" r="2"/><circle cx="430" cy="130" r="2"/>
  </g>
  <circle cx="430" cy="90" r="16" fill="#ffca28" stroke="#333"/><text x="460" y="95" font-family="Arial" font-size="13">Passive Buzzer</text>
  <circle cx="430" cy="130" r="12" fill="#2e7d32"/><text x="460" y="135" font-family="Arial" font-size="13">LED</text>
  <line x1="80" y1="91" x2="300" y2="91" stroke="#1976d2" stroke-width="3"/>
  <line x1="300" y1="91" x2="414" y2="91" stroke="#1976d2" stroke-width="3"/>
  <line x1="80" y1="121" x2="300" y2="121" stroke="#ef6c00" stroke-width="3"/>
  <line x1="300" y1="121" x2="418" y2="121" stroke="#ef6c00" stroke-width="3"/>
  <line x1="80" y1="151" x2="300" y2="151" stroke="#424242" stroke-width="3"/>
  <line x1="300" y1="151" x2="430" y2="151" stroke="#424242" stroke-width="3"/>
  <text x="620" y="250" font-family="Arial" font-size="13">D6 -> buzzer, D10 -> LED via 220R, GND common</text>
</svg>`,
        buildSteps: [
          "Wire buzzer and LED according to diagram.",
          "Upload sketch to board.",
          "Observe pulse sequence and decode long/short pattern as clue digits.",
        ],
        arduinoCode: `const int buzzerPin = 6;
const int ledPin = 10;
const int codePattern[] = {200, 200, 600, 200, 600};

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  for (int i = 0; i < 5; i++) {
    tone(buzzerPin, 1200);
    digitalWrite(ledPin, HIGH);
    delay(codePattern[i]);
    noTone(buzzerPin);
    digitalWrite(ledPin, LOW);
    delay(250);
  }
  delay(2000);
}`,
      },
    },
    {
      id: "pz_electronic_4",
      category: "electronic",
      themeTags: ["generic", "modern-electronics"],
      title: "Capacitive Touch Sequence",
      objective: "Touch sensor pads in the correct order to reveal a clue.",
      howItWorks:
        "Players discover an ordered hint and trigger capacitive pads accordingly. The Arduino validates sequence timing and activates an output when correct.",
      referenceLinks: [
        { title: "Playful Technology channel", url: "https://www.youtube.com/@playfultechnology" },
        {
          title: "Arduino touch sensor puzzle (YouTube)",
          url: "https://www.youtube.com/results?search_query=arduino+touch+sensor+escape+room+puzzle",
        },
      ],
      solveSteps: ["Wire touch pads", "Upload sketch", "Enter discovered sequence"],
      difficulty: "medium",
      electronicDetails: {
        parts: [
          "Arduino Uno (or compatible)",
          "MPR121 touch sensor module (or equivalent)",
          "3 conductive touch pads",
          "Breadboard",
          "Jumper wires",
          "USB cable",
        ],
        wiringDiagram: [
          "MPR121 SDA/SCL -> Arduino SDA/SCL",
          "MPR121 VCC -> 5V, GND -> GND",
          "Pad outputs -> MPR121 electrode pins",
          "D9 -> status LED (optional) through 220 ohm resistor",
        ],
        wiringDiagramSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="760" height="260" viewBox="0 0 760 260"><rect x="20" y="20" width="180" height="220" fill="#f4f6f8" stroke="#333"/><text x="110" y="45" text-anchor="middle" font-family="Arial" font-size="15">Arduino</text><rect x="250" y="30" width="220" height="100" fill="#fff" stroke="#333"/><text x="360" y="55" text-anchor="middle" font-family="Arial" font-size="14">MPR121</text><circle cx="560" cy="70" r="14" fill="#ddd" stroke="#333"/><circle cx="610" cy="70" r="14" fill="#ddd" stroke="#333"/><circle cx="660" cy="70" r="14" fill="#ddd" stroke="#333"/><text x="610" y="110" text-anchor="middle" font-family="Arial" font-size="12">Touch Pads</text><line x1="80" y1="90" x2="250" y2="70" stroke="#1976d2" stroke-width="2.5"/><line x1="80" y1="120" x2="250" y2="90" stroke="#1976d2" stroke-width="2.5"/><line x1="80" y1="150" x2="250" y2="110" stroke="#e53935" stroke-width="2.5"/><line x1="80" y1="180" x2="250" y2="120" stroke="#424242" stroke-width="2.5"/><line x1="470" y1="70" x2="546" y2="70" stroke="#fb8c00" stroke-width="2.5"/><line x1="470" y1="85" x2="596" y2="70" stroke="#fb8c00" stroke-width="2.5"/><line x1="470" y1="100" x2="646" y2="70" stroke="#fb8c00" stroke-width="2.5"/></svg>`,
        buildSteps: [
          "Wire MPR121 module and pads.",
          "Upload sequence-validation sketch.",
          "Test each pad, then validate full sequence.",
        ],
        arduinoCode: `// Pseudo sketch outline for MPR121 sequence validation
int seq[4] = {0,2,1,2};
int pos = 0;
void onPadTouch(int pad){
  if(pad == seq[pos]) pos++;
  else pos = 0;
  if(pos == 4){ /* unlock output */ }
}`,
      },
    },
    {
      id: "pz_electronic_5",
      category: "electronic",
      themeTags: ["generic", "modern-electronics"],
      title: "RFID Access Chain",
      objective: "Scan RFID tags in the right order to unlock the next clue.",
      howItWorks:
        "Players find tagged props and infer a sequence rule. The Arduino checks scan order and triggers unlock feedback when valid.",
      referenceLinks: [
        { title: "Playful Technology channel", url: "https://www.youtube.com/@playfultechnology" },
        {
          title: "RFID escape room puzzle (YouTube)",
          url: "https://www.youtube.com/results?search_query=rfid+escape+room+puzzle+arduino",
        },
      ],
      solveSteps: ["Wire RFID reader", "Register tag IDs", "Scan in required order"],
      difficulty: "medium",
      electronicDetails: {
        parts: [
          "Arduino Uno (or compatible)",
          "MFRC522 RFID module",
          "3 RFID tags/cards",
          "Breadboard",
          "Jumper wires",
          "USB cable",
        ],
        wiringDiagram: ["SPI pins to RFID module", "5V/GND power rails", "D9 output LED via 220 ohm resistor"],
        wiringDiagramSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="760" height="260" viewBox="0 0 760 260"><rect x="20" y="20" width="180" height="220" fill="#f4f6f8" stroke="#333"/><text x="110" y="45" text-anchor="middle" font-family="Arial" font-size="15">Arduino</text><rect x="260" y="40" width="180" height="120" fill="#fff" stroke="#333"/><text x="350" y="68" text-anchor="middle" font-family="Arial" font-size="14">MFRC522 RFID</text><rect x="520" y="45" width="70" height="40" fill="#eee" stroke="#333"/><rect x="600" y="45" width="70" height="40" fill="#eee" stroke="#333"/><rect x="560" y="95" width="70" height="40" fill="#eee" stroke="#333"/><text x="600" y="155" text-anchor="middle" font-family="Arial" font-size="12">RFID tags</text><line x1="90" y1="90" x2="260" y2="80" stroke="#1976d2" stroke-width="2.5"/><line x1="90" y1="110" x2="260" y2="95" stroke="#1976d2" stroke-width="2.5"/><line x1="90" y1="130" x2="260" y2="110" stroke="#1976d2" stroke-width="2.5"/><line x1="90" y1="150" x2="260" y2="125" stroke="#1976d2" stroke-width="2.5"/></svg>`,
        buildSteps: ["Wire RFID reader over SPI.", "Upload sketch and register tags.", "Validate unlock sequence."],
        arduinoCode: `// Pseudo RFID order check
String needed[3]={"TAG1","TAG3","TAG2"}; int pos=0;
void onTag(String id){ if(id==needed[pos]) pos++; else pos=0; if(pos==3){ /* unlock */ } }`,
      },
    },
    {
      id: "pz_electronic_6",
      category: "electronic",
      themeTags: ["generic", "modern-electronics"],
      title: "Laser Trip Alignment",
      objective: "Align mirrors/sensors to complete all beam paths.",
      howItWorks:
        "Players redirect low-power laser lines into photo sensors. When all channels are aligned simultaneously, the controller triggers the success signal.",
      referenceLinks: [
        { title: "Playful Technology channel", url: "https://www.youtube.com/@playfultechnology" },
        {
          title: "Laser sensor escape room build (YouTube)",
          url: "https://www.youtube.com/results?search_query=laser+sensor+escape+room+puzzle",
        },
      ],
      solveSteps: ["Mount emitter/sensors", "Align beams", "Hold all channels stable"],
      difficulty: "hard",
      electronicDetails: {
        parts: [
          "Arduino Uno (or compatible)",
          "3x photoresistors or photodiodes",
          "Low-power laser modules",
          "3x 10k resistors",
          "Breadboard and jumpers",
        ],
        wiringDiagram: ["Photo sensors to analog pins with divider resistors", "Laser modules to power rails", "D10 status output"],
        wiringDiagramSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="760" height="260" viewBox="0 0 760 260"><rect x="20" y="20" width="180" height="220" fill="#f4f6f8" stroke="#333"/><text x="110" y="45" text-anchor="middle" font-family="Arial" font-size="15">Arduino</text><circle cx="330" cy="80" r="10" fill="#ff5252"/><circle cx="330" cy="120" r="10" fill="#ff5252"/><circle cx="330" cy="160" r="10" fill="#ff5252"/><rect x="460" y="60" width="20" height="20" fill="#ddd" stroke="#333"/><rect x="460" y="100" width="20" height="20" fill="#ddd" stroke="#333"/><rect x="460" y="140" width="20" height="20" fill="#ddd" stroke="#333"/><line x1="340" y1="80" x2="460" y2="70" stroke="#f44336" stroke-width="2"/><line x1="340" y1="120" x2="460" y2="110" stroke="#f44336" stroke-width="2"/><line x1="340" y1="160" x2="460" y2="150" stroke="#f44336" stroke-width="2"/></svg>`,
        buildSteps: ["Wire analog sensor channels.", "Mount lasers and sensor targets.", "Tune threshold values in sketch."],
        arduinoCode: `// Pseudo alignment check
if(a0>t && a1>t && a2>t){ /* unlock */ }`,
      },
    },
    {
      id: "pz_electronic_3_old_west",
      category: "electronic",
      themeTags: ["old-west", "signal"],
      title: "Telegraph Relay Key",
      objective: "Send the correct telegraph pulse sequence to unlock the marshal's safe clue.",
      howItWorks:
        "Players use a telegraph-style key connected to an Arduino input. Entering the right pulse rhythm simulates a period-correct telegraph code and triggers the unlock signal.",
      referenceLinks: [
        { title: "Playful Technology channel", url: "https://www.youtube.com/@playfultechnology" },
        { title: "Puzzle Pieces channel", url: "https://www.youtube.com/@PuzzlePieces" },
        {
          title: "Telegraph puzzle inspiration (YouTube)",
          url: "https://www.youtube.com/results?search_query=telegraph+escape+room+puzzle",
        },
      ],
      solveSteps: ["Connect telegraph key switch", "Input pulse sequence", "Read unlocked clue"],
      difficulty: "medium",
      electronicDetails: {
        parts: [
          "Arduino Uno (or compatible)",
          "Momentary push switch (telegraph key style)",
          "Breadboard",
          "1x LED",
          "1x 220 ohm resistor",
          "1x 10k ohm resistor",
          "Jumper wires",
          "USB cable",
        ],
        wiringDiagram: [
          "D2 -> telegraph key output with 10k pulldown to GND",
          "5V -> telegraph key input",
          "D9 -> 220 ohm resistor -> LED anode",
          "LED cathode -> GND",
        ],
        wiringDiagramSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="860" height="300" viewBox="0 0 860 300"><rect x="20" y="20" width="220" height="240" fill="#f4f6f8" stroke="#333"/><text x="130" y="46" text-anchor="middle" font-family="Arial" font-size="16">Arduino Uno</text><text x="40" y="90" font-family="Arial" font-size="13">D2</text><text x="40" y="120" font-family="Arial" font-size="13">D9</text><text x="40" y="150" font-family="Arial" font-size="13">5V</text><text x="40" y="180" font-family="Arial" font-size="13">GND</text><rect x="290" y="20" width="550" height="240" fill="#fff" stroke="#333"/><text x="565" y="46" text-anchor="middle" font-family="Arial" font-size="16">Telegraph Key Circuit</text><rect x="540" y="95" width="120" height="28" fill="#ddd" stroke="#333"/><text x="670" y="114" font-family="Arial" font-size="12">Telegraph Key</text><circle cx="500" cy="150" r="10" fill="#2e7d32"/><text x="516" y="154" font-family="Arial" font-size="12">LED</text><polyline points="460,150 472,144 484,156 496,144 508,156 520,150" fill="none" stroke="#8d6e63" stroke-width="2"/><text x="524" y="154" font-family="Arial" font-size="11">220R</text><polyline points="460,205 472,199 484,211 496,199 508,211 520,205" fill="none" stroke="#8d6e63" stroke-width="2"/><text x="524" y="209" font-family="Arial" font-size="11">10k</text><line x1="80" y1="86" x2="540" y2="109" stroke="#fb8c00" stroke-width="2.5"/><line x1="80" y1="146" x2="540" y2="109" stroke="#e53935" stroke-width="2.5"/><line x1="660" y1="109" x2="460" y2="205" stroke="#fb8c00" stroke-width="2.5"/><line x1="520" y1="205" x2="760" y2="220" stroke="#424242" stroke-width="2.5"/><line x1="80" y1="176" x2="760" y2="220" stroke="#424242" stroke-width="2.5"/><line x1="80" y1="116" x2="460" y2="150" stroke="#1976d2" stroke-width="2.5"/></svg>`,
        buildSteps: [
          "Wire telegraph key and LED as shown.",
          "Upload sketch and open serial monitor.",
          "Tap the key in the correct pattern to complete puzzle.",
        ],
        arduinoCode: `const int keyPin = 2;
const int ledPin = 9;
int count = 0;
unsigned long lastTap = 0;
void setup(){pinMode(keyPin,INPUT);pinMode(ledPin,OUTPUT);}
void loop(){
  if(digitalRead(keyPin)==HIGH && millis()-lastTap>180){lastTap=millis();count++;}
  if(count>=5){digitalWrite(ledPin,HIGH);}
}`,
      },
    },
  ],
};

const createAuthTokenForUser = (user: AuthUser): string => {
  const authToken = `tok_${user.id}_${Date.now()}`;
  authTokens.set(authToken, user.id);
  return authToken;
};

const upsertSocialUser = (provider: AuthUser["provider"], email: string, name: string): AuthUser => {
  const normalizedEmail = email.trim().toLowerCase();
  let user = usersByEmail.get(normalizedEmail);
  if (!user) {
    user = {
      id: `usr_${nextUserId++}`,
      name: name.trim(),
      email: normalizedEmail,
      provider,
    };
    usersByEmail.set(normalizedEmail, user);
  }
  return user;
};

const buildAuthSuccessRedirect = (returnTo: string, authToken: string, user: AuthUser): string => {
  const url = new URL(returnTo);
  url.searchParams.set("auth_token", authToken);
  url.searchParams.set("auth_user", encodeURIComponent(JSON.stringify({
    id: user.id,
    name: user.name,
    email: user.email,
    provider: user.provider,
  })));
  return url.toString();
};

const cleanupExpiredOauthStates = (): void => {
  const now = Date.now();
  for (const [state, payload] of oauthStateStore.entries()) {
    if (now - payload.createdAtMs > OAUTH_STATE_TTL_MS) oauthStateStore.delete(state);
  }
};

const readAuthUserId = (req: express.Request): string | undefined => {
  const authHeader = String(req.headers.authorization ?? "");
  if (!authHeader.toLowerCase().startsWith("bearer ")) return undefined;
  const token = authHeader.slice(7).trim();
  if (!token) return undefined;
  return authTokens.get(token);
};

const persistSavedPlans = async (): Promise<void> => {
  const serialized = Array.from(savedPlansByUser.entries()).flatMap(([userId, plans]) =>
    plans.map((plan) => ({ ...plan, userId })),
  );
  await fs.mkdir(path.dirname(savedPlansPath), { recursive: true });
  await fs.writeFile(savedPlansPath, JSON.stringify(serialized, null, 2), "utf8");
};

const loadSavedPlans = async (): Promise<void> => {
  try {
    const raw = await fs.readFile(savedPlansPath, "utf8");
    const parsed = JSON.parse(raw) as SavedPlan[];
    savedPlansByUser.clear();
    for (const plan of parsed) {
      const list = savedPlansByUser.get(plan.userId) ?? [];
      list.push(plan);
      savedPlansByUser.set(plan.userId, list);
    }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
      // eslint-disable-next-line no-console
      console.warn("Could not load saved plans:", error);
    }
  }
};

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/auth/signup", (req, res) => {
  const { name, email, password } = req.body ?? {};
  if (!name || !email || !password) {
    res.status(400).json({
      error: { code: "VALIDATION_ERROR", message: "name, email, and password are required.", details: [] },
    });
    return;
  }
  const normalizedEmail = String(email).trim().toLowerCase();
  if (usersByEmail.has(normalizedEmail)) {
    res.status(409).json({
      error: { code: "EMAIL_EXISTS", message: "An account with this email already exists.", details: [] },
    });
    return;
  }
  const user: AuthUser = {
    id: `usr_${nextUserId++}`,
    name: String(name).trim(),
    email: normalizedEmail,
    provider: "local",
    password: String(password),
  };
  usersByEmail.set(normalizedEmail, user);
  const authToken = `tok_${user.id}_${Date.now()}`;
  authTokens.set(authToken, user.id);
  res.status(201).json({
    authToken,
    user: { id: user.id, name: user.name, email: user.email, provider: user.provider },
  });
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body ?? {};
  if (!email || !password) {
    res.status(400).json({
      error: { code: "VALIDATION_ERROR", message: "email and password are required.", details: [] },
    });
    return;
  }
  const normalizedEmail = String(email).trim().toLowerCase();
  const user = usersByEmail.get(normalizedEmail);
  if (!user || user.provider !== "local" || user.password !== String(password)) {
    res.status(401).json({
      error: { code: "INVALID_CREDENTIALS", message: "Invalid email or password.", details: [] },
    });
    return;
  }
  const authToken = `tok_${user.id}_${Date.now()}`;
  authTokens.set(authToken, user.id);
  res.json({
    authToken,
    user: { id: user.id, name: user.name, email: user.email, provider: user.provider },
  });
});

app.get("/api/auth/oauth/:provider/start", (req, res) => {
  cleanupExpiredOauthStates();
  const provider = String(req.params.provider ?? "").toLowerCase() as "google" | "facebook" | "github";
  const allowedProviders = new Set(["google", "facebook", "github"]);
  if (!allowedProviders.has(provider)) {
    res.status(400).json({
      error: { code: "VALIDATION_ERROR", message: "provider must be google, facebook, or github.", details: [] },
    });
    return;
  }

  const returnTo = String(req.query.returnTo ?? "").trim() || "http://localhost:5173/";
  const callbackBaseUrl = String(process.env.AUTH_CALLBACK_BASE_URL ?? "").trim();
  const clientId = String(process.env[`${provider.toUpperCase()}_CLIENT_ID`] ?? "").trim();
  const clientSecret = String(process.env[`${provider.toUpperCase()}_CLIENT_SECRET`] ?? "").trim();
  if (!callbackBaseUrl || !clientId || !clientSecret) {
    res.status(501).json({
      error: {
        code: "SOCIAL_AUTH_NOT_CONFIGURED",
        message: `Missing OAuth env vars for ${provider}. Configure AUTH_CALLBACK_BASE_URL, ${provider.toUpperCase()}_CLIENT_ID, and ${provider.toUpperCase()}_CLIENT_SECRET.`,
        details: [],
      },
    });
    return;
  }

  const callbackUri = `${callbackBaseUrl.replace(/\/$/, "")}/api/auth/oauth/${provider}/callback`;
  const state = `${provider}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  oauthStateStore.set(state, { provider, returnTo, createdAtMs: Date.now() });

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: callbackUri,
    state,
  });
  if (provider === "google") {
    params.set("response_type", "code");
    params.set("scope", "openid email profile");
    params.set("access_type", "offline");
    params.set("prompt", "select_account");
    res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
    return;
  }
  if (provider === "facebook") {
    params.set("response_type", "code");
    params.set("scope", "email,public_profile");
    res.redirect(`https://www.facebook.com/v20.0/dialog/oauth?${params.toString()}`);
    return;
  }
  params.set("scope", "read:user user:email");
  res.redirect(`https://github.com/login/oauth/authorize?${params.toString()}`);
});

app.get("/api/auth/oauth/:provider/callback", async (req, res) => {
  cleanupExpiredOauthStates();
  const provider = String(req.params.provider ?? "").toLowerCase() as "google" | "facebook" | "github";
  const code = String(req.query.code ?? "");
  const state = String(req.query.state ?? "");
  const stateData = oauthStateStore.get(state);
  if (!code || !stateData || stateData.provider !== provider) {
    res.status(400).json({
      error: { code: "OAUTH_CALLBACK_INVALID", message: "Invalid or expired OAuth callback state.", details: [] },
    });
    return;
  }
  oauthStateStore.delete(state);

  try {
    const callbackBaseUrl = String(process.env.AUTH_CALLBACK_BASE_URL ?? "").trim();
    const clientId = String(process.env[`${provider.toUpperCase()}_CLIENT_ID`] ?? "").trim();
    const clientSecret = String(process.env[`${provider.toUpperCase()}_CLIENT_SECRET`] ?? "").trim();
    const callbackUri = `${callbackBaseUrl.replace(/\/$/, "")}/api/auth/oauth/${provider}/callback`;
    let email = "";
    let name = "";

    if (provider === "google") {
      const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: callbackUri,
          grant_type: "authorization_code",
        }),
      });
      if (!tokenResponse.ok) throw new Error("Google token exchange failed.");
      const tokenData = (await tokenResponse.json()) as { access_token?: string; id_token?: string };
      const tokenToVerify = tokenData.id_token || tokenData.access_token;
      if (!tokenToVerify) throw new Error("Google token payload missing id_token/access_token.");
      const verifyResponse = await fetch(
        `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(tokenToVerify)}`,
      );
      if (!verifyResponse.ok) throw new Error("Google token verification failed.");
      const verifyData = (await verifyResponse.json()) as { email?: string; name?: string };
      email = String(verifyData.email ?? "").trim().toLowerCase();
      name = String(verifyData.name ?? "Google User").trim();
    } else if (provider === "facebook") {
      const tokenResponse = await fetch(
        `https://graph.facebook.com/v20.0/oauth/access_token?${new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: callbackUri,
          code,
        }).toString()}`,
      );
      if (!tokenResponse.ok) throw new Error("Facebook token exchange failed.");
      const tokenData = (await tokenResponse.json()) as { access_token?: string };
      if (!tokenData.access_token) throw new Error("Facebook token payload missing access_token.");
      const profileResponse = await fetch(
        `https://graph.facebook.com/me?${new URLSearchParams({
          fields: "id,name,email",
          access_token: tokenData.access_token,
        }).toString()}`,
      );
      if (!profileResponse.ok) throw new Error("Facebook profile lookup failed.");
      const profileData = (await profileResponse.json()) as { email?: string; name?: string; id?: string };
      email = String(profileData.email ?? `${profileData.id}@facebook.local`).trim().toLowerCase();
      name = String(profileData.name ?? "Facebook User").trim();
    } else {
      const tokenResponse = await fetch("https://github.com/login/oauth/access_token", {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          code,
          redirect_uri: callbackUri,
        }),
      });
      if (!tokenResponse.ok) throw new Error("GitHub token exchange failed.");
      const tokenData = (await tokenResponse.json()) as { access_token?: string };
      if (!tokenData.access_token) throw new Error("GitHub token payload missing access_token.");
      const profileResponse = await fetch("https://api.github.com/user", {
        headers: { Authorization: `Bearer ${tokenData.access_token}`, Accept: "application/vnd.github+json" },
      });
      if (!profileResponse.ok) throw new Error("GitHub profile lookup failed.");
      const profileData = (await profileResponse.json()) as { email?: string; name?: string; login?: string };
      if (profileData.email) {
        email = String(profileData.email).trim().toLowerCase();
      } else {
        const emailsResponse = await fetch("https://api.github.com/user/emails", {
          headers: { Authorization: `Bearer ${tokenData.access_token}`, Accept: "application/vnd.github+json" },
        });
        if (!emailsResponse.ok) throw new Error("GitHub email lookup failed.");
        const emailsData = (await emailsResponse.json()) as Array<{ email: string; primary?: boolean; verified?: boolean }>;
        const primary = emailsData.find((entry) => entry.primary && entry.verified) ?? emailsData[0];
        email = String(primary?.email ?? "").trim().toLowerCase();
      }
      name = String(profileData.name ?? profileData.login ?? "GitHub User").trim();
    }

    if (!email) throw new Error(`${provider} account did not provide a usable email.`);
    const user = upsertSocialUser(provider, email, name);
    const authToken = createAuthTokenForUser(user);
    res.redirect(buildAuthSuccessRedirect(stateData.returnTo, authToken, user));
  } catch (error) {
    res.status(401).json({
      error: {
        code: "SOCIAL_AUTH_VERIFICATION_FAILED",
        message: `OAuth verification failed for ${provider}.`,
        details: [String(error instanceof Error ? error.message : error)],
      },
    });
  }
});

app.post("/api/planning/session", (req, res) => {
  // Validate planning payload and start a new session state.
  const {
    playersConcurrent,
    participantsTotal,
    sessionDurationMinutes,
    environmentType,
    availableItems,
    existingPuzzles,
  } = req.body ?? {};
  if (
    !playersConcurrent ||
    !participantsTotal ||
    !sessionDurationMinutes ||
    !environmentType ||
    !Array.isArray(availableItems) ||
    availableItems.length === 0
  ) {
    res.status(400).json({
      error: {
        code: "VALIDATION_ERROR",
        message: "Missing required planning input fields.",
        details: [],
      },
    });
    return;
  }
  const newSessionId = `sess_${nextSessionId++}`;
  sessions.set(newSessionId, {
    planningInput: {
      playersConcurrent: Number(playersConcurrent),
      participantsTotal: Number(participantsTotal),
      sessionDurationMinutes: Number(sessionDurationMinutes),
      environmentType: String(environmentType),
      availableItems: availableItems.map((item: unknown) => String(item)),
      existingPuzzles: Array.isArray(existingPuzzles)
        ? existingPuzzles
            .filter(
              (puzzle: unknown) =>
                typeof puzzle === "object" &&
                puzzle !== null &&
                typeof (puzzle as { name?: unknown }).name === "string" &&
                typeof (puzzle as { link?: unknown }).link === "string" &&
                typeof (puzzle as { roomPart?: unknown }).roomPart === "string",
            )
            .map((puzzle: { name: string; link: string; roomPart: string }) => ({
              name: puzzle.name.trim(),
              link: puzzle.link.trim(),
              roomPart: puzzle.roomPart.trim(),
            }))
            .filter((puzzle: { name: string; link: string; roomPart: string }) => puzzle.name && puzzle.link && puzzle.roomPart)
        : [],
    },
    customThemes: [],
    generatedThemes: [],
    generatedThemeCount: 0,
    seenThemeIds: new Set<string>(),
    seenPuzzleIds: new Set<string>(),
    currentPuzzles: [],
    suggestedAdditions: [],
  });
  res.status(201).json({
    sessionId: newSessionId,
    createdAt: new Date().toISOString(),
  });
});

app.post("/api/themes/generate", (req, res) => {
  // Produce an initial theme set while minimizing repeats.
  const { sessionId } = req.body ?? {};
  const session = sessionId ? sessions.get(sessionId) : undefined;
  if (!session) {
    res.status(400).json({ error: { code: "INVALID_SESSION", message: "sessionId is required.", details: [] } });
    return;
  }
  const initialThemes = shuffle(
    themePool.filter((theme) => !globallyServedThemeIds.has(theme.id) && !isSkipped("theme", theme.id)),
  ).slice(0, 3);
  while (initialThemes.length < 3) {
    const generated = createGeneratedTheme("th_global_generated");
    if (
      globallyServedThemeIds.has(generated.id) ||
      globallyServedThemeNames.has(generated.name) ||
      isSkipped("theme", generated.id)
    ) {
      continue;
    }
    initialThemes.push(generated);
  }
  initialThemes.forEach((theme) => session.seenThemeIds.add(theme.id));
  initialThemes.forEach((theme) => globallyServedThemeIds.add(theme.id));
  initialThemes.forEach((theme) => globallyServedThemeNames.add(theme.name));
  session.generatedThemes = initialThemes;
  res.json({
    themes: initialThemes,
  });
});

app.post("/api/themes/refresh", (req, res) => {
  // Refresh returns unseen themes for this session.
  const { sessionId, excludeThemeIds } = req.body ?? {};
  const session = sessionId ? sessions.get(sessionId) : undefined;
  if (!session) {
    res.status(400).json({ error: { code: "INVALID_SESSION", message: "sessionId is required.", details: [] } });
    return;
  }
  const requestExcludes = new Set<string>(Array.isArray(excludeThemeIds) ? excludeThemeIds : []);
  requestExcludes.forEach((id) => markSkipped("theme", id));
  void persistSkipHistory();
  const excludes = new Set<string>([...requestExcludes, ...session.seenThemeIds]);
  const refreshed = shuffle(themePool.filter((theme) => !excludes.has(theme.id) && !isSkipped("theme", theme.id))).slice(
    0,
    3,
  );

  // Ensure refresh always returns 3 brand-new theme IDs with zero overlap.
  while (refreshed.length < 3) {
    session.generatedThemeCount += 1;
    const generated = createGeneratedTheme(`th_generated_${sessionId}`);
    if (
      excludes.has(generated.id) ||
      session.seenThemeIds.has(generated.id) ||
      globallyServedThemeNames.has(generated.name) ||
      isSkipped("theme", generated.id)
    ) {
      continue;
    }
    refreshed.push(generated);
  }
  refreshed.forEach((theme) => session.seenThemeIds.add(theme.id));
  refreshed.forEach((theme) => globallyServedThemeIds.add(theme.id));
  refreshed.forEach((theme) => globallyServedThemeNames.add(theme.name));
  session.generatedThemes = refreshed;

  res.json({
    themes: refreshed,
  });
});

app.post("/api/themes/custom", (req, res) => {
  // Support user-authored themes and include them in selectable options.
  const { sessionId, name, description } = req.body ?? {};
  const session = sessionId ? sessions.get(sessionId) : undefined;
  if (!session) {
    res.status(400).json({ error: { code: "INVALID_SESSION", message: "sessionId is required.", details: [] } });
    return;
  }
  if (!name || typeof name !== "string" || !name.trim()) {
    res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Custom theme name is required.", details: [] } });
    return;
  }
  const customTheme: Theme = {
    id: `th_custom_${nextThemeId++}`,
    name: name.trim(),
    description:
      typeof description === "string" && description.trim()
        ? description.trim()
        : "Custom theme provided by user.",
  };
  session.customThemes.push(customTheme);
  session.generatedThemes = [customTheme, ...session.generatedThemes.filter((theme) => theme.id !== customTheme.id)];
  session.seenThemeIds.add(customTheme.id);
  res.status(201).json({ theme: customTheme });
});

app.post("/api/planning/session/:sessionId/existing-puzzles", (req, res) => {
  const sessionId = req.params.sessionId;
  const session = sessions.get(sessionId);
  if (!session) {
    res.status(404).json({ error: { code: "INVALID_SESSION", message: "Session not found.", details: [] } });
    return;
  }
  const { existingPuzzles } = req.body ?? {};
  if (!Array.isArray(existingPuzzles)) {
    res.status(400).json({
      error: { code: "VALIDATION_ERROR", message: "existingPuzzles must be an array.", details: [] },
    });
    return;
  }
  session.planningInput.existingPuzzles = existingPuzzles
    .filter(
      (puzzle: unknown) =>
        typeof puzzle === "object" &&
        puzzle !== null &&
        typeof (puzzle as { name?: unknown }).name === "string" &&
        typeof (puzzle as { link?: unknown }).link === "string" &&
        typeof (puzzle as { roomPart?: unknown }).roomPart === "string",
    )
    .map((puzzle: { name: string; link: string; roomPart: string }) => ({
      name: puzzle.name.trim(),
      link: puzzle.link.trim(),
      roomPart: puzzle.roomPart.trim(),
    }))
    .filter((puzzle: { name: string; link: string; roomPart: string }) => puzzle.name && puzzle.link && puzzle.roomPart);
  res.json({ existingPuzzles: session.planningInput.existingPuzzles });
});

app.post("/api/puzzles/generate", (req, res) => {
  // Build a theme-compatible puzzle set sized to players/time.
  const { sessionId, themeId } = req.body ?? {};
  const session = sessionId ? sessions.get(sessionId) : undefined;
  if (!session) {
    res.status(400).json({ error: { code: "INVALID_SESSION", message: "sessionId is required.", details: [] } });
    return;
  }
  if (!themeId) {
    res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "themeId is required.", details: [] } });
    return;
  }
  const selectedTheme =
    themePool.find((theme) => theme.id === themeId) ??
    session.generatedThemes.find((theme) => theme.id === themeId) ??
    session.customThemes.find((theme) => theme.id === themeId);
  if (!selectedTheme) {
    res.status(404).json({ error: { code: "THEME_NOT_FOUND", message: "Theme not found for this session.", details: [] } });
    return;
  }
  session.selectedTheme = selectedTheme;
  const generationSeenIds = new Set<string>();
  const pickPuzzle = (category: Puzzle["category"]): Puzzle => {
    const compatible = puzzlePoolByCategory[category].filter(
      (puzzle) => isPuzzleCompatibleWithTheme(puzzle, session.selectedTheme) && !isSkipped("puzzle", puzzle.id),
    );
    const unseen = compatible.find(
      (puzzle) => !session.seenPuzzleIds.has(puzzle.id) && !generationSeenIds.has(puzzle.id),
    );
    if (unseen) return unseen;
    const notYetInThisBatch = compatible.find((puzzle) => !generationSeenIds.has(puzzle.id));
    return notYetInThisBatch ?? compatible[0] ?? puzzlePoolByCategory[category][0];
  };
  const totalPuzzleCount = estimatePuzzleCount(
    session.planningInput.playersConcurrent,
    session.planningInput.sessionDurationMinutes,
  );
  const context = getThemeContext(session.selectedTheme);
  const existingPuzzleTemplates: Puzzle[] = session.planningInput.existingPuzzles.map((existing, index) => {
    const query = encodeURIComponent(`${existing.name} escape room puzzle build`);
    return {
      id: `pz_existing_${sessionId}_${index + 1}`,
      category: "physical",
      themeTags: context.requiredTag ? ["generic", "user-provided", context.requiredTag] : ["generic", "user-provided"],
      title: existing.name,
      objective: `Use this prebuilt puzzle in the "${existing.roomPart}" part of the room flow.`,
      howItWorks: `User-provided puzzle scheduled for the "${existing.roomPart}" segment.`,
      stageHint: existing.roomPart,
      referenceLinks: [
        { title: `Primary build guide: ${existing.name}`, url: existing.link },
        {
          title: `Video examples for ${existing.name}`,
          url: `https://www.youtube.com/results?search_query=${query}`,
        },
        {
          title: "Puzzle Pieces channel",
          url: "https://www.youtube.com/@PuzzlePieces",
        },
      ],
      solveSteps: ["Set up puzzle using the primary build guide", "Integrate into room sequence"],
      difficulty: "medium",
    };
  });

  const remainingPuzzleCount = Math.max(totalPuzzleCount - existingPuzzleTemplates.length, 0);
  const sessionMinutes = session.planningInput.sessionDurationMinutes;
  let electronicCount = Math.max(1, Math.ceil(remainingPuzzleCount * 0.4));
  let logicCount = Math.max(1, Math.floor(remainingPuzzleCount * 0.3));
  let physicalCount = Math.max(1, remainingPuzzleCount - electronicCount - logicCount);

  // Short sessions should avoid too many complex electronic chains.
  if (sessionMinutes <= 10) {
    electronicCount = Math.min(electronicCount, 1);
    logicCount = Math.min(logicCount, 1);
    physicalCount = Math.max(1, remainingPuzzleCount - electronicCount - logicCount);
  } else if (sessionMinutes <= 15) {
    electronicCount = Math.min(electronicCount, 1);
    physicalCount = Math.max(1, remainingPuzzleCount - electronicCount - logicCount);
  }

  const generated: Puzzle[] = [...existingPuzzleTemplates];
  for (let i = 0; i < logicCount; i += 1) {
    const puzzle = pickPuzzle("logic");
    generated.push(puzzle);
    generationSeenIds.add(puzzle.id);
  }
  for (let i = 0; i < physicalCount; i += 1) {
    const puzzle = pickPuzzle("physical");
    generated.push(puzzle);
    generationSeenIds.add(puzzle.id);
  }
  for (let i = 0; i < electronicCount; i += 1) {
    const puzzle = pickPuzzle("electronic");
    generated.push(puzzle);
    generationSeenIds.add(puzzle.id);
  }

  // De-duplicate in case a small category pool is exhausted.
  const uniqueGenerated = Array.from(new Map(generated.map((puzzle) => [puzzle.id, puzzle])).values());
  const generatedWithReasons = withThemeFitReasons(uniqueGenerated, session.selectedTheme);
  const generatedForResponse = withSingleReferenceLink(generatedWithReasons);
  generatedForResponse.forEach((puzzle) => session.seenPuzzleIds.add(puzzle.id));
  session.currentPuzzles = generatedForResponse;
  session.suggestedAdditions = getSuggestedAdditions(session, generatedForResponse);
  session.currentStoryPlan = createStoryPlan(session.selectedTheme, generatedForResponse);
  const compatibilityPassed = generatedForResponse.every((puzzle) =>
    isPuzzleCompatibleWithTheme(puzzle, session.selectedTheme),
  );
  res.json({
    puzzles: generatedForResponse,
    compatibilityPassed,
    storyPlan: session.currentStoryPlan,
    suggestedAdditions: session.suggestedAdditions,
  });
});

app.post("/api/puzzles/:puzzleId/replace", (req, res) => {
  // Replace a single puzzle with another compatible candidate.
  const { sessionId } = req.body ?? {};
  const puzzleId = req.params.puzzleId;
  const session = sessionId ? sessions.get(sessionId) : undefined;
  if (!session) {
    res.status(400).json({ error: { code: "INVALID_SESSION", message: "sessionId is required.", details: [] } });
    return;
  }
  const target = session.currentPuzzles.find((puzzle) => puzzle.id === puzzleId);
  if (!target) {
    res
      .status(404)
      .json({ error: { code: "PUZZLE_NOT_FOUND", message: "Puzzle is not in current session set.", details: [] } });
    return;
  }
  const replacement =
    puzzlePoolByCategory[target.category].filter(
      (puzzle) => isPuzzleCompatibleWithTheme(puzzle, session.selectedTheme) && !isSkipped("puzzle", puzzle.id),
    ).find(
      (puzzle) => puzzle.id !== puzzleId && !session.seenPuzzleIds.has(puzzle.id),
    ) ??
    puzzlePoolByCategory[target.category]
      .filter((puzzle) => isPuzzleCompatibleWithTheme(puzzle, session.selectedTheme) && !isSkipped("puzzle", puzzle.id))
      .find((puzzle) => puzzle.id !== puzzleId);
  if (!replacement) {
    res.status(409).json({
      error: { code: "NO_REPLACEMENT_AVAILABLE", message: "No valid replacement found for this puzzle.", details: [] },
    });
    return;
  }
  markSkipped("puzzle", puzzleId);
  void persistSkipHistory();
  session.seenPuzzleIds.add(replacement.id);
  session.currentPuzzles = session.currentPuzzles.map((puzzle) => (puzzle.id === puzzleId ? replacement : puzzle));
  session.currentPuzzles = withThemeFitReasons(session.currentPuzzles, session.selectedTheme);
  session.currentPuzzles = withSingleReferenceLink(session.currentPuzzles);
  session.suggestedAdditions = getSuggestedAdditions(session, session.currentPuzzles);
  session.currentStoryPlan = createStoryPlan(session.selectedTheme, session.currentPuzzles);
  const compatibilityPassed = session.currentPuzzles.every((puzzle) =>
    isPuzzleCompatibleWithTheme(puzzle, session.selectedTheme),
  );
  res.json({
    replacedPuzzleId: puzzleId,
    newPuzzle: replacement,
    compatibilityPassed,
    storyPlan: session.currentStoryPlan,
    suggestedAdditions: session.suggestedAdditions,
  });
});

app.post("/api/plans/:sessionId/export", (req, res) => {
  // Export full planning output for host/runbook usage.
  const sessionId = req.params.sessionId;
  const session = sessions.get(sessionId);
  if (!session) {
    res.status(404).json({ error: { code: "INVALID_SESSION", message: "Session not found.", details: [] } });
    return;
  }
  session.currentPuzzles = withThemeFitReasons(session.currentPuzzles, session.selectedTheme);
  session.currentPuzzles = withSingleReferenceLink(session.currentPuzzles);
  const lines = [
    "# Escape Room Plan",
    "",
    "## Session",
    `- ID: ${sessionId}`,
    "",
    "## Planning Input",
    `- Players at one time: ${session.planningInput.playersConcurrent}`,
    `- Total participants: ${session.planningInput.participantsTotal}`,
    `- Session duration (minutes): ${session.planningInput.sessionDurationMinutes}`,
    `- Environment (physical room): ${session.planningInput.environmentType}`,
    `- Available items: ${session.planningInput.availableItems.join(", ")}`,
    `- Existing user puzzles: ${session.planningInput.existingPuzzles.length}`,
    ...session.planningInput.existingPuzzles.map(
      (puzzle) => `  - ${puzzle.name} [${puzzle.roomPart}]: ${puzzle.link}`,
    ),
    "",
    "## Theme",
    `- Name: ${session.selectedTheme?.name ?? "Not selected"}`,
    `- Description: ${session.selectedTheme?.description ?? "No description provided."}`,
    `- Theme compatibility checks passed: ${
      session.currentPuzzles.every((puzzle) => isPuzzleCompatibleWithTheme(puzzle, session.selectedTheme))
        ? "Yes"
        : "No"
    }`,
    "",
    "## Storyline",
    `- Situation: ${session.currentStoryPlan?.situation ?? "Not generated yet."}`,
    `- Premise: ${session.currentStoryPlan?.premise ?? "Not generated yet."}`,
    `- Mission objective: ${session.currentStoryPlan?.missionObjective ?? "Not generated yet."}`,
    `- Progression rule: ${
      session.currentStoryPlan?.progressionRule ??
      "At least two puzzle elements should be solved before each reveal."
    }`,
    "",
    "## Stage Flow",
    ...(session.currentStoryPlan?.stages ?? []).flatMap((stage) => [
      `### ${stage.title}`,
      `- Story beat: ${stage.storyBeat}`,
      `- Why this stage exists: ${stage.whyThisStageExists}`,
      `- Objective: ${stage.objective}`,
      "- What players must do:",
      ...stage.whatPlayersMustDo.map((step) => `  - ${step}`),
      `- Required puzzles: ${stage.requiredPuzzleTitles.join(" and ")}`,
      `- Reveal: ${stage.reveals}`,
      "",
    ]),
    "## Puzzle-to-Story Mapping",
    ...(session.currentStoryPlan?.puzzleLinks ?? []).map(
      (link) => `- ${link.puzzleTitle}: ${link.storyRole}. ${link.unlocks}`,
    ),
    "",
    "## Puzzles",
    ...session.currentPuzzles.map(
      (puzzle) => `- ${puzzle.title} (${puzzle.category}, ${puzzle.difficulty}): ${puzzle.objective}`,
    ),
    "",
    "## Puzzle Explanations",
    ...session.currentPuzzles.map((puzzle) => `- ${puzzle.title}: ${puzzle.howItWorks}`),
    "",
    "## Suggested Elements to Add (If Needed)",
    ...(session.suggestedAdditions.length > 0
      ? session.suggestedAdditions.map((item) => `- ${item}`)
      : ["- No additional elements suggested."]),
    "",
    "## Theme Fit Rationale",
    ...session.currentPuzzles.map(
      (puzzle) => `- ${puzzle.title}: ${deriveThemeFitReason(puzzle, session.selectedTheme)}`,
    ),
    "",
    "## Puzzle Video and Build References",
    ...session.currentPuzzles.flatMap((puzzle) => [
      `### ${puzzle.title}`,
      ...(puzzle.referenceLinks ?? []).map((ref) => `- [${ref.title}](${ref.url})`),
      "",
    ]),
    "",
    "## Electronic Puzzle Implementation Details",
    ...session.currentPuzzles
      .filter((puzzle) => puzzle.category === "electronic" && puzzle.electronicDetails)
      .flatMap((puzzle) => [
        `### ${puzzle.title}`,
        "- Parts:",
        ...((puzzle.electronicDetails?.parts ?? []).map((part) => `  - ${part}`)),
        "- Wiring:",
        ...((puzzle.electronicDetails?.wiringDiagram ?? []).map((wire) => `  - ${wire}`)),
        "- Build Steps:",
        ...((puzzle.electronicDetails?.buildSteps ?? []).map((step) => `  - ${step}`)),
        "- Arduino Code:",
        "```cpp",
        puzzle.electronicDetails?.arduinoCode ?? "",
        "```",
        "",
      ]),
  ];
  const format = req.body?.format ?? "markdown";
  const content = lines.join("\n");
  res.json({
    planId: `plan_${sessionId}`,
    format,
    content,
  });
});

app.post("/api/plans/:sessionId/save", async (req, res) => {
  const userId = readAuthUserId(req);
  if (!userId) {
    res.status(401).json({ error: { code: "UNAUTHORIZED", message: "Auth token is required.", details: [] } });
    return;
  }
  const sessionId = req.params.sessionId;
  const session = sessions.get(sessionId);
  if (!session) {
    res.status(404).json({ error: { code: "INVALID_SESSION", message: "Session not found.", details: [] } });
    return;
  }
  const approvedForBuild = Boolean(req.body?.approvedForBuild);
  if (!approvedForBuild) {
    res.status(400).json({
      error: { code: "VALIDATION_ERROR", message: "Plan must be approved for build before saving.", details: [] },
    });
    return;
  }
  const planName = String(req.body?.name ?? "").trim() || `${session.selectedTheme?.name ?? "Untitled"} Plan`;
  const compatibilityPassed = session.currentPuzzles.every((puzzle) =>
    isPuzzleCompatibleWithTheme(puzzle, session.selectedTheme),
  );
  const nowIso = new Date().toISOString();
  const plan: SavedPlan = {
    planId: `saved_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    userId,
    sessionId,
    name: planName,
    approvedForBuild,
    createdAt: nowIso,
    updatedAt: nowIso,
    data: {
      planningInput: session.planningInput,
      themes: session.generatedThemes.length ? session.generatedThemes : [...session.customThemes],
      selectedThemeId: session.selectedTheme?.id ?? "",
      puzzles: session.currentPuzzles,
      suggestedAdditions: session.suggestedAdditions,
      storyPlan: session.currentStoryPlan ?? null,
      compatibilityPassed,
      exportContent: "",
    },
  };
  const current = savedPlansByUser.get(userId) ?? [];
  current.unshift(plan);
  savedPlansByUser.set(userId, current.slice(0, 100));
  await persistSavedPlans();
  res.status(201).json({
    savedPlan: {
      planId: plan.planId,
      name: plan.name,
      approvedForBuild: plan.approvedForBuild,
      createdAt: plan.createdAt,
      updatedAt: plan.updatedAt,
      sessionId,
    },
  });
});

app.get("/api/plans/saved", (req, res) => {
  const userId = readAuthUserId(req);
  if (!userId) {
    res.status(401).json({ error: { code: "UNAUTHORIZED", message: "Auth token is required.", details: [] } });
    return;
  }
  const plans = (savedPlansByUser.get(userId) ?? []).map((plan) => ({
    planId: plan.planId,
    name: plan.name,
    approvedForBuild: plan.approvedForBuild,
    sessionId: plan.sessionId,
    createdAt: plan.createdAt,
    updatedAt: plan.updatedAt,
    themeName: plan.data.themes.find((theme) => theme.id === plan.data.selectedThemeId)?.name ?? "Unknown Theme",
    puzzleCount: plan.data.puzzles.length,
  }));
  res.json({ plans });
});

app.get("/api/plans/saved/:planId", (req, res) => {
  const userId = readAuthUserId(req);
  if (!userId) {
    res.status(401).json({ error: { code: "UNAUTHORIZED", message: "Auth token is required.", details: [] } });
    return;
  }
  const planId = req.params.planId;
  const plan = (savedPlansByUser.get(userId) ?? []).find((entry) => entry.planId === planId);
  if (!plan) {
    res.status(404).json({ error: { code: "PLAN_NOT_FOUND", message: "Saved plan not found.", details: [] } });
    return;
  }
  res.json({ savedPlan: plan });
});

app.delete("/api/plans/saved/:planId", async (req, res) => {
  const userId = readAuthUserId(req);
  if (!userId) {
    res.status(401).json({ error: { code: "UNAUTHORIZED", message: "Auth token is required.", details: [] } });
    return;
  }
  const planId = req.params.planId;
  const current = savedPlansByUser.get(userId) ?? [];
  const next = current.filter((entry) => entry.planId !== planId);
  if (next.length === current.length) {
    res.status(404).json({ error: { code: "PLAN_NOT_FOUND", message: "Saved plan not found.", details: [] } });
    return;
  }
  savedPlansByUser.set(userId, next);
  await persistSavedPlans();
  res.json({ deletedPlanId: planId, remaining: next.length });
});

app.get("/api/debug/skip-history", (_req, res) => {
  pruneExpiredSkips();
  const now = Date.now();
  const entries = Array.from(skipEntries.values()).map((entry) => ({
    ...entry,
    expiresAtMs: entry.skippedAtMs + SKIP_TTL_MS,
    remainingMs: Math.max(entry.skippedAtMs + SKIP_TTL_MS - now, 0),
  }));
  res.json({ count: entries.length, entries });
});

app.delete("/api/debug/skip-history", (req, res) => {
  const type = req.query.type as SkipEntryType | undefined;
  const id = req.query.id as string | undefined;

  if (type && type !== "theme" && type !== "puzzle") {
    res.status(400).json({
      error: { code: "VALIDATION_ERROR", message: "type must be 'theme' or 'puzzle'.", details: [] },
    });
    return;
  }

  let removed = 0;
  if (!type && !id) {
    removed = skipEntries.size;
    skipEntries.clear();
  } else {
    for (const [key, entry] of skipEntries.entries()) {
      const typeMatch = !type || entry.type === type;
      const idMatch = !id || entry.id === id;
      if (typeMatch && idMatch) {
        skipEntries.delete(key);
        removed += 1;
      }
    }
  }

  void persistSkipHistory();
  res.json({ removed, remaining: skipEntries.size });
});

const port = process.env.PORT || 3001;
void (async () => {
  await loadSkipHistory();
  await loadSavedPlans();
  app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`Backend running on http://localhost:${port}`);
  });
})();

